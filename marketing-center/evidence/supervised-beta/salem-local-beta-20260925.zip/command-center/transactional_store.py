from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
import json
import sqlite3
import uuid
from typing import Callable


def _canonical(value: object) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


@dataclass(frozen=True)
class OutboxRecord:
    sequence: int
    event_id: str
    event_type: str
    state_version: int
    payload: dict
    created_at: str
    delivered_at: str | None


class SQLiteStateOutbox:
    """Transactional state document plus durable outbox.

    Each mutation opens its own SQLite connection, takes an IMMEDIATE write
    transaction, reads the latest state, applies one bounded mutation, writes
    the next state version, and inserts the outbox record before COMMIT.
    This makes the state update and event durable as one atomic unit across
    independent processes that share the same database file.
    """

    def __init__(self, path: str | Path, *, timeout_seconds: float = 10.0):
        self.path = Path(path)
        self.timeout_seconds = float(timeout_seconds)
        if self.timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be positive")

    def _connect(self) -> sqlite3.Connection:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(
            self.path,
            timeout=self.timeout_seconds,
            isolation_level=None,
        )
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=FULL")
        connection.execute("PRAGMA foreign_keys=ON")
        return connection

    def initialize(self, initial_state: dict | None = None) -> None:
        state = {} if initial_state is None else initial_state
        if not isinstance(state, dict):
            raise ValueError("initial_state must be an object")
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS state_document (
                    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
                    version INTEGER NOT NULL,
                    document TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS outbox (
                    sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_id TEXT NOT NULL UNIQUE,
                    event_type TEXT NOT NULL,
                    state_version INTEGER NOT NULL,
                    payload TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    delivered_at TEXT NULL
                )
                """
            )
            existing = connection.execute(
                "SELECT 1 FROM state_document WHERE singleton = 1"
            ).fetchone()
            if existing is None:
                connection.execute(
                    """
                    INSERT INTO state_document(singleton, version, document, updated_at)
                    VALUES (1, 0, ?, ?)
                    """,
                    (_canonical(state), _now()),
                )
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def read_state(self) -> tuple[dict, int]:
        connection = self._connect()
        try:
            row = connection.execute(
                "SELECT document, version FROM state_document WHERE singleton = 1"
            ).fetchone()
            if row is None:
                raise RuntimeError("store is not initialized")
            document = json.loads(row["document"])
            if not isinstance(document, dict):
                raise RuntimeError("stored state document is invalid")
            return document, int(row["version"])
        finally:
            connection.close()

    def mutate(
        self,
        mutator: Callable[[dict], dict | None],
        *,
        event_type: str,
        event_payload: dict,
        event_id: str | None = None,
    ) -> tuple[dict, int, OutboxRecord]:
        if not callable(mutator):
            raise ValueError("mutator must be callable")
        if not str(event_type).strip():
            raise ValueError("event_type is required")
        if not isinstance(event_payload, dict):
            raise ValueError("event_payload must be an object")
        chosen_event_id = event_id or str(uuid.uuid4())

        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT document, version FROM state_document WHERE singleton = 1"
            ).fetchone()
            if row is None:
                raise RuntimeError("store is not initialized")
            current = json.loads(row["document"])
            if not isinstance(current, dict):
                raise RuntimeError("stored state document is invalid")
            working = json.loads(_canonical(current))
            result = mutator(working)
            next_state = working if result is None else result
            if not isinstance(next_state, dict):
                raise ValueError("mutator must return an object or None")
            next_version = int(row["version"]) + 1
            stamp = _now()
            connection.execute(
                """
                UPDATE state_document
                SET version = ?, document = ?, updated_at = ?
                WHERE singleton = 1
                """,
                (next_version, _canonical(next_state), stamp),
            )
            cursor = connection.execute(
                """
                INSERT INTO outbox(
                    event_id, event_type, state_version, payload, created_at, delivered_at
                )
                VALUES (?, ?, ?, ?, ?, NULL)
                """,
                (
                    chosen_event_id,
                    event_type,
                    next_version,
                    _canonical(event_payload),
                    stamp,
                ),
            )
            sequence = int(cursor.lastrowid)
            connection.commit()
            record = OutboxRecord(
                sequence=sequence,
                event_id=chosen_event_id,
                event_type=event_type,
                state_version=next_version,
                payload=json.loads(_canonical(event_payload)),
                created_at=stamp,
                delivered_at=None,
            )
            return next_state, next_version, record
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def pending(self, *, limit: int = 100) -> tuple[OutboxRecord, ...]:
        if limit <= 0 or limit > 1000:
            raise ValueError("limit must be between 1 and 1000")
        connection = self._connect()
        try:
            rows = connection.execute(
                """
                SELECT sequence, event_id, event_type, state_version,
                       payload, created_at, delivered_at
                FROM outbox
                WHERE delivered_at IS NULL
                ORDER BY sequence ASC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
            return tuple(self._row_to_record(row) for row in rows)
        finally:
            connection.close()

    def mark_delivered(self, event_id: str) -> bool:
        if not str(event_id).strip():
            raise ValueError("event_id is required")
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            cursor = connection.execute(
                """
                UPDATE outbox
                SET delivered_at = ?
                WHERE event_id = ? AND delivered_at IS NULL
                """,
                (_now(), event_id),
            )
            changed = cursor.rowcount == 1
            connection.commit()
            return changed
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def integrity_check(self) -> bool:
        connection = self._connect()
        try:
            row = connection.execute("PRAGMA integrity_check").fetchone()
            return bool(row and row[0] == "ok")
        finally:
            connection.close()

    @staticmethod
    def _row_to_record(row: sqlite3.Row) -> OutboxRecord:
        payload = json.loads(row["payload"])
        if not isinstance(payload, dict):
            raise RuntimeError("outbox payload is invalid")
        return OutboxRecord(
            sequence=int(row["sequence"]),
            event_id=row["event_id"],
            event_type=row["event_type"],
            state_version=int(row["state_version"]),
            payload=payload,
            created_at=row["created_at"],
            delivered_at=row["delivered_at"],
        )
