#!/usr/bin/env python3
import hashlib, hmac, json, os, re, threading, uuid, time
from functools import wraps
from datetime import datetime, timezone
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

ROOT=Path(__file__).resolve().parent
APP=ROOT/"app"
DATA=ROOT/"data"
STATE=DATA/"state.json"
EVENTS=DATA/"events.jsonl"
LOCK=threading.Lock()
STATE_LOCK=threading.RLock()
SESSION_EPOCH=uuid.uuid4().hex
WORKER_STATES={"IDLE","RUNNING","WAITING_FOR_TOOL","WAITING_FOR_OWNER","WAITING_FOR_DEPENDENCY","RETRYING","STALLED","FAILED","COMPLETE","OFFLINE"}
RUN_TERMINAL_STATES={"COMPLETE","FAILED","REJECTED"}
EVIDENCE_KINDS={"receipt","checkpoint","result"}
SHA256_REF=re.compile(r"sha256:([0-9a-f]{64})")

def serialized_mutation(function):
    @wraps(function)
    def wrapped(*args,**kwargs):
        with STATE_LOCK:
            return function(*args,**kwargs)
    return wrapped

def now():
    return datetime.now(timezone.utc).isoformat().replace("+00:00","Z")

def load_state():
    with LOCK:
        with STATE.open("r",encoding="utf-8") as f:
            state=json.load(f)
    state.setdefault("runs",[])
    state.setdefault("providers",[])
    state.setdefault("attention",[])
    return state

def save_state(state):
    with LOCK:
        tmp=STATE.with_suffix(".tmp")
        with tmp.open("w",encoding="utf-8") as f:
            json.dump(state,f,indent=2)
            f.write("\n")
        os.replace(tmp,STATE)

def append_event(event):
    event=dict(event)
    event.setdefault("id",str(uuid.uuid4()))
    event.setdefault("created_at",now())
    with LOCK:
        with EVENTS.open("a",encoding="utf-8") as f:
            f.write(json.dumps(event,separators=(",",":"))+"\n")
    return event

def evidence_path(reference):
    match=SHA256_REF.fullmatch(str(reference or ""))
    if not match:
        raise ValueError("evidence reference must be sha256:<64 lowercase hex>")
    return DATA/"evidence"/f"{match.group(1)}.json"

def read_evidence(reference):
    path=evidence_path(reference)
    try:
        content=path.read_bytes()
    except FileNotFoundError as error:
        raise ValueError("evidence reference was not found") from error
    digest=hashlib.sha256(content).hexdigest()
    if path.stem!=digest:
        raise ValueError("evidence content hash does not match reference")
    try:
        record=json.loads(content)
    except (UnicodeDecodeError,json.JSONDecodeError) as error:
        raise ValueError("evidence record is invalid") from error
    if not isinstance(record,dict):
        raise ValueError("evidence record is invalid")
    return record

def require_evidence(reference,kind,run_id,worker_id):
    record=read_evidence(reference)
    if (record.get("kind")!=kind or record.get("run_id")!=run_id
            or record.get("worker_id")!=worker_id):
        raise ValueError(f"{kind} evidence does not match run and worker")
    return record

@serialized_mutation
def store_evidence(payload):
    run_id=payload.get("run_id")
    worker_id=payload.get("worker_id")
    kind=payload.get("kind")
    evidence=payload.get("evidence")
    if not run_id or not worker_id or kind not in EVIDENCE_KINDS:
        raise ValueError("run_id, worker_id and kind receipt, checkpoint or result are required")
    if not isinstance(evidence,dict) or not evidence:
        raise ValueError("evidence must be a nonempty object")
    state=load_state()
    run=run_record(state,run_id)
    if not run:
        raise KeyError("run not found")
    if run.get("worker_id")!=worker_id:
        raise ValueError("worker does not own run")
    if kind=="result" and run.get("protocol")=="cooperative-v1":
        require_session(state,run,payload,require_runnable=True)
    if kind in {"receipt","checkpoint"} and run.get("status") not in {"QUEUED","APPROVED"}:
        raise ValueError("receipt and checkpoint evidence require a pending run")
    if kind=="result" and run.get("status")!="RUNNING":
        raise ValueError("result evidence requires an acknowledged running run")
    record={"version":1,"kind":kind,"run_id":run_id,"worker_id":worker_id,
            "created_at":now(),"evidence":evidence}
    if kind=="result" and run.get("protocol")=="cooperative-v1":
        record['session_generation']=run['session_generation']
    content=(json.dumps(record,sort_keys=True,separators=(",",":"),ensure_ascii=False)+"\n").encode("utf-8")
    digest=hashlib.sha256(content).hexdigest()
    reference=f"sha256:{digest}"
    directory=DATA/"evidence"
    directory.mkdir(parents=True,exist_ok=True)
    destination=directory/f"{digest}.json"
    if destination.exists():
        if destination.read_bytes()!=content:
            raise RuntimeError("evidence digest collision")
    else:
        temporary=directory/f".{digest}.{uuid.uuid4().hex}.tmp"
        try:
            with temporary.open("xb") as file:
                file.write(content)
                file.flush()
                os.fsync(file.fileno())
            os.replace(temporary,destination)
        finally:
            temporary.unlink(missing_ok=True)
    return reference,record

def project(state,pid):
    return next((p for p in state["projects"] if p["id"]==pid),None)

def run_record(state,run_id):
    return next((r for r in state.get("runs",[]) if r["id"]==run_id),None)

def provider_record(state,provider_id):
    return next((p for p in state.get("providers",[]) if p["id"]==provider_id),None)

@serialized_mutation
def apply_control(payload):
    required={"type","project_id"}
    if not required.issubset(payload):
        raise ValueError("type and project_id are required")
    state=load_state()
    p=project(state,payload["project_id"])
    if not p:
        raise KeyError("project not found")
    typ=payload["type"]
    allowed={"PAUSE_REQUESTED","RESUME_REQUESTED","RETRY_REQUESTED","INSTRUCTION","APPROVAL","REJECTION","DEFER","REROUTE_REQUESTED"}
    if typ not in allowed:
        raise ValueError("unsupported control event")
    if typ=="INSTRUCTION" and not str(payload.get("instruction","")).strip():
        raise ValueError("instruction is required")
    attention=None
    if typ in {"APPROVAL","REJECTION","DEFER"}:
        blocker_id=payload.get("blocker_id")
        if not blocker_id:
            raise ValueError("blocker_id is required")
        attention=next((a for a in state.get("attention",[]) if a.get("id")==blocker_id and a.get("project_id")==p["id"]),None)
        if not attention:
            raise ValueError("attention item not found for project")
    event=append_event({**payload,"requested_by":payload.get("requested_by","owner")})
    if typ=="PAUSE_REQUESTED":
        p["desired_state"]="PAUSED"
    elif typ=="RESUME_REQUESTED":
        p["desired_state"]="RUNNING"
    elif typ=="RETRY_REQUESTED":
        p["desired_state"]="RETRY"
    elif typ=="REROUTE_REQUESTED":
        p["desired_state"]="REROUTE"
    elif typ in {"APPROVAL","REJECTION"}:
        attention["status"]="RESOLVED"
        attention["resolution"]=typ
        attention["resolution_event_id"]=event["id"]
        attention["resolved_at"]=event["created_at"]
        related_run=run_record(state,attention.get("run_id")) if attention.get("run_id") else None
        if related_run and related_run.get("status") not in RUN_TERMINAL_STATES:
            if typ=="APPROVAL":
                related_run["status"]="APPROVED"
                related_run["approved_at"]=event["created_at"]
                related_run["approval_event_id"]=event["id"]
                p["status"]="RUNNING"
                p["desired_state"]="RUNNING"
            else:
                related_run["status"]="REJECTED"
                related_run["rejected_at"]=event["created_at"]
                related_run["approval_event_id"]=event["id"]
                p["status"]="WAITING"
                p["desired_state"]="PAUSED"
            related_run["updated_at"]=event["created_at"]
    elif typ=="DEFER":
        attention["last_deferred_at"]=event["created_at"]
    p["last_control_event_id"]=event["id"]
    p["updated_at"]=event["created_at"]
    save_state(state)
    return event,state

@serialized_mutation
def apply_heartbeat(payload):
    worker_id=payload.get("worker_id")
    if not worker_id:
        raise ValueError("worker_id is required")
    if "progress" in payload and not isinstance(payload["progress"],bool):
        raise ValueError("progress must be a boolean")
    requested_state=payload.get("state")
    if requested_state is not None and requested_state not in WORKER_STATES:
        raise ValueError("invalid worker state")
    state=load_state()
    w=next((x for x in state["workers"] if x["id"]==worker_id),None)
    if not w:
        raise KeyError("worker not found")
    if "current_project_id" in payload and payload["current_project_id"] is not None:
        if not project(state,payload["current_project_id"]):
            raise ValueError("current project not found")
    w["last_heartbeat_at"]=now()
    if payload.get("progress"):
        w["last_progress_at"]=now()
    if requested_state is not None:
        w["state"]=requested_state
    if "current_project_id" in payload:
        w["current_project_id"]=payload["current_project_id"]
    save_state(state)
    append_event({"type":"HEARTBEAT","project_id":w.get("current_project_id") or "none","worker_id":w["id"],"requested_by":"worker"})
    return w

@serialized_mutation
def request_execution(payload):
    project_id=payload.get("project_id")
    provider_id=payload.get("provider_id")
    action=str(payload.get("action","")).strip()
    worker_id=payload.get("worker_id")
    if not project_id or not provider_id or not worker_id or not action:
        raise ValueError("project_id, provider_id, worker_id and action are required")
    state=load_state()
    p=project(state,project_id)
    if not p:
        raise KeyError("project not found")
    provider=provider_record(state,provider_id)
    if not provider or not provider.get("enabled",False):
        raise ValueError("provider is missing or disabled")
    worker=next((w for w in state.get("workers",[]) if w.get("id")==worker_id),None)
    if not worker:
        raise ValueError("worker is missing")
    if p.get("assigned_worker_id")!=worker_id:
        raise ValueError("worker is not assigned to project")
    run_id=payload.get("run_id") or str(uuid.uuid4())
    if run_record(state,run_id):
        raise ValueError("run_id already exists")
    requires_approval=bool(payload.get("requires_owner_approval",False))
    created=now()
    run={
        "id":run_id,
        "project_id":project_id,
        "provider_id":provider_id,
        "worker_id":worker_id,
        "action":action,
        "status":"WAITING_FOR_OWNER" if requires_approval else "QUEUED",
        "requires_owner_approval":requires_approval,
        "created_at":created,
        "updated_at":created
    }
    if "input" in payload:
        run["input"]=payload["input"]
    if 'protocol' in payload:
        if payload['protocol']!='cooperative-v1':
            raise ValueError('unsupported execution protocol')
        run['protocol']=payload['protocol']
    state["runs"].append(run)
    if requires_approval:
        blocker_id=f"run-{run_id}"
        state["attention"].append({
            "id":blocker_id,
            "project_id":project_id,
            "run_id":run_id,
            "title":"Execution requires owner approval",
            "detail":f"{provider_id}: {action}",
            "type":"OWNER",
            "status":"OPEN"
        })
        p["status"]="WAITING_FOR_OWNER"
        p["desired_state"]="PAUSED"
    event=append_event({
        "type":"EXECUTION_REQUESTED",
        "project_id":project_id,
        "run_id":run_id,
        "provider_id":provider_id,
        "worker_id":worker_id,
        "requested_by":payload.get("requested_by","controller"),
        "requires_owner_approval":requires_approval
    })
    run["request_event_id"]=event["id"]
    p["updated_at"]=event["created_at"]
    save_state(state)
    return run,state

@serialized_mutation
def acknowledge_execution(payload):
    run_id=payload.get("run_id")
    worker_id=payload.get("worker_id")
    receipt_ref=str(payload.get("receipt_ref","")).strip()
    checkpoint_ref=str(payload.get("checkpoint_ref","")).strip()
    if not run_id or not worker_id or not receipt_ref or not checkpoint_ref:
        raise ValueError("run_id, worker_id, receipt_ref and checkpoint_ref are required")
    state=load_state()
    run=run_record(state,run_id)
    if not run:
        raise KeyError("run not found")
    if run.get('protocol')=='cooperative-v1':
        raise ValueError('cooperative run requires session acquisition')
    if run.get("worker_id")!=worker_id:
        raise ValueError("worker does not own run")
    if run.get("status") not in {"QUEUED","APPROVED"}:
        raise ValueError("run is not ready for acknowledgement")
    require_evidence(receipt_ref,"receipt",run_id,worker_id)
    require_evidence(checkpoint_ref,"checkpoint",run_id,worker_id)
    stamp=now()
    run.update(status="RUNNING",receipt_ref=receipt_ref,checkpoint_ref=checkpoint_ref,
               acknowledged_at=stamp,updated_at=stamp)
    event=append_event({"type":"EXECUTION_ACKNOWLEDGED","project_id":run["project_id"],
                        "run_id":run_id,"worker_id":worker_id,"provider_id":run["provider_id"],
                        "receipt_ref":receipt_ref,"checkpoint_ref":checkpoint_ref,
                        "requested_by":"worker"})
    run["acknowledgement_event_id"]=event["id"]
    save_state(state)
    return run,state

@serialized_mutation
def complete_execution(payload):
    run_id=payload.get("run_id")
    status=payload.get("status")
    worker_id=payload.get("worker_id")
    evidence_ref=str(payload.get("evidence_ref","")).strip()
    if not run_id or not worker_id or status not in {"COMPLETE","FAILED"}:
        raise ValueError("run_id, worker_id and status COMPLETE or FAILED are required")
    state=load_state()
    run=run_record(state,run_id)
    if not run:
        raise KeyError("run not found")
    if run.get("worker_id")!=worker_id:
        raise ValueError("worker does not own run")
    if run.get('protocol')=='cooperative-v1':
        require_session(state,run,payload,require_runnable=True)
    if run.get("status")=="WAITING_FOR_OWNER":
        raise ValueError("owner approval is required before completion")
    if run.get("status")=="REJECTED":
        raise ValueError("run was rejected by owner")
    if run.get("status") in RUN_TERMINAL_STATES:
        raise ValueError("run is already terminal")
    if run.get("status")!="RUNNING":
        raise ValueError("worker acknowledgement is required before completion")
    if not run.get("receipt_ref") or not run.get("checkpoint_ref"):
        raise ValueError("receipt and checkpoint are required before completion")
    if not evidence_ref:
        raise ValueError("evidence_ref is required before completion")
    result_record=require_evidence(evidence_ref,"result",run_id,worker_id)
    if (run.get('protocol')=='cooperative-v1'
            and result_record.get('session_generation')!=run.get('session_generation')):
        raise ValueError('result evidence belongs to a previous session')
    p=project(state,run["project_id"])
    stamp=now()
    run.update(status=status,updated_at=stamp,completed_at=stamp,evidence_ref=evidence_ref)
    if payload.get("summary"):
        run["summary"]=payload["summary"]
    event=append_event({
        "type":"EXECUTION_COMPLETED" if status=="COMPLETE" else "EXECUTION_FAILED",
        "project_id":run["project_id"],"run_id":run_id,"provider_id":run["provider_id"],
        "worker_id":worker_id,"requested_by":"worker","evidence_ref":evidence_ref})
    run["completion_event_id"]=event["id"]
    if p:
        p["status"]="COMPLETE" if status=="COMPLETE" else "FAILED"
        p["updated_at"]=event["created_at"]
    if run.get('protocol')=='cooperative-v1':
        worker=next(w for w in state['workers'] if w['id']==worker_id)
        worker.update(state=status,last_heartbeat_at=stamp,last_progress_at=stamp)
    save_state(state)
    return run,state

def api_token_status(authorization):
    token=os.environ.get("ZENTRYVA_CONTROL_TOKEN")
    if not token:
        return "NOT_CONFIGURED"
    expected=f"Bearer {token}"
    return "AUTHORIZED" if hmac.compare_digest(authorization or "",expected) else "UNAUTHORIZED"

def worker_token_status(worker_id,authorization):
    try:
        tokens=json.loads(os.environ.get("ZENTRYVA_WORKER_TOKENS","{}"))
    except json.JSONDecodeError:
        return "NOT_CONFIGURED"
    token=tokens.get(worker_id) if isinstance(tokens,dict) else None
    if not token:
        return "NOT_CONFIGURED"
    expected=f"Bearer {token}"
    return "AUTHORIZED" if hmac.compare_digest(authorization or "",expected) else "UNAUTHORIZED"

def pending_executions(worker_id):
    state=load_state()
    if not any(w.get("id")==worker_id for w in state.get("workers",[])):
        raise KeyError("worker not found")
    return [r for r in state.get("runs",[])
            if r.get("worker_id")==worker_id and r.get("status") in {"QUEUED","APPROVED"}]


# Single-process, local cooperative execution. Monotonic deadlines bound elapsed
# lifetime; a process epoch invalidates old sessions after a server restart.
def lease_clock():
    return time.time()


def active_lease(run):
    return (run.get('session_epoch')==SESSION_EPOCH
            and run.get('lease_until',0)>lease_clock()
            and run.get('lease_monotonic_until',0)>time.monotonic())


def run_runnable(state,run):
    p=project(state,run['project_id'])
    provider=provider_record(state,run['provider_id'])
    return bool(p and p.get('desired_state')=='RUNNING'
                and p.get('assigned_worker_id')==run['worker_id']
                and provider and provider.get('enabled') is True)


def require_session(state,run,payload,require_runnable=False):
    session=payload.get('session_id')
    if (run.get('protocol')!='cooperative-v1' or run.get('status')!='RUNNING'
            or run.get('worker_id')!=payload.get('worker_id')
            or not isinstance(session,str) or not re.fullmatch('[0-9a-f]{32}',session)
            or not hmac.compare_digest(run.get('session_hash',''),hashlib.sha256(session.encode()).hexdigest())):
        raise ValueError('execution session is not active')
    if not active_lease(run):
        # Once observed expired, the same capability can never revive on a
        # subsequent clock adjustment. This state change is serialized.
        run.update(lease_until=0,lease_monotonic_until=0)
        save_state(state)
        raise ValueError('execution session is not active')
    if require_runnable and not run_runnable(state,run):
        raise ValueError('execution is suspended by shared control')


@serialized_mutation
def worker_run_status(run_id,worker_id):
    state=load_state()
    run=run_record(state,run_id)
    if not run or run.get('worker_id')!=worker_id:
        raise KeyError('run not found')
    # Explicit projection: no other tenant records or capability IDs.
    fields=('id','project_id','provider_id','worker_id','action','status','input',
            'protocol','requires_owner_approval','receipt_ref','checkpoint_ref','evidence_ref')
    view=dict(run={k:run[k] for k in fields if k in run},runnable=run_runnable(state,run))
    if run.get('status') in {'COMPLETE','FAILED'} and run.get('evidence_ref'):
        view['result']=require_evidence(run['evidence_ref'],'result',run_id,worker_id)['evidence']
    return view


@serialized_mutation
def acquire_execution(payload):
    state=load_state()
    run=run_record(state,payload.get('run_id'))
    if not run or run.get('worker_id')!=payload.get('worker_id'):
        raise KeyError('run not found')
    session=payload.get('session_id')
    if not isinstance(session,str) or not re.fullmatch('[0-9a-f]{32}',session):
        raise ValueError('invalid execution session')
    if (run.get('protocol')!='cooperative-v1' or run.get('status') not in {'QUEUED','APPROVED','RUNNING'}
            or not run_runnable(state,run)):
        raise ValueError('run is not available for acquisition')
    if run.get('status')=='RUNNING' and active_lease(run):
        raise ValueError('run already has an active session')
    if run.get('status') in {'QUEUED','APPROVED'}:
        for kind in ('receipt','checkpoint'):
            ref=payload.get(kind+'_ref')
            require_evidence(ref,kind,run['id'],run['worker_id'])
            run[kind+'_ref']=ref
    run.update(status='RUNNING',session_hash=hashlib.sha256(session.encode()).hexdigest(),lease_until=lease_clock()+30,
               session_epoch=SESSION_EPOCH,lease_monotonic_until=time.monotonic()+30,
               session_generation=run.get('session_generation',0)+1,updated_at=now())
    worker=next(w for w in state['workers'] if w['id']==run['worker_id'])
    worker.update(state='RUNNING',current_project_id=run['project_id'],
                  last_progress_at=now(),last_heartbeat_at=now())
    append_event(dict(type='EXECUTION_ACQUIRED',run_id=run['id'],worker_id=run['worker_id'],
                      project_id=run['project_id'],generation=run['session_generation']))
    save_state(state)
    return worker_run_status(run['id'],run['worker_id'])


@serialized_mutation
def pulse_execution(payload):
    state=load_state()
    run=run_record(state,payload.get('run_id'))
    if not run: raise KeyError('run not found')
    require_session(state,run,payload)
    runnable=run_runnable(state,run)
    run['lease_until']=lease_clock()+30
    run['lease_monotonic_until']=time.monotonic()+30
    worker=next(w for w in state['workers'] if w['id']==run['worker_id'])
    worker.update(state='RUNNING' if runnable else 'WAITING_FOR_DEPENDENCY',
                  last_heartbeat_at=now(),current_project_id=run['project_id'])
    save_state(state)
    return dict(runnable=runnable)


@serialized_mutation
def release_execution(payload):
    state=load_state()
    run=run_record(state,payload.get('run_id'))
    if not run: raise KeyError('run not found')
    require_session(state,run,payload)
    run['lease_until']=0
    run['lease_monotonic_until']=0
    worker=next(w for w in state['workers'] if w['id']==run['worker_id'])
    worker.update(state='WAITING_FOR_DEPENDENCY',last_heartbeat_at=now())
    save_state(state)
    return dict(released=True)


def worker_mutation_view(run,state):
    """Legacy acknowledgement compatibility without cross-project state leakage."""
    view=worker_run_status(run['id'],run['worker_id'])
    p=project(state,run['project_id'])
    provider=provider_record(state,run['provider_id'])
    view['state']=dict(
        projects=[{k:p[k] for k in ('id','desired_state','assigned_worker_id') if k in p}] if p else [],
        providers=[{k:provider[k] for k in ('id','enabled') if k in provider}] if provider else [])
    return view

@serialized_mutation
def supervisor_tick():
    state=load_state()
    changed=False
    now_dt=datetime.now(timezone.utc)
    threshold=state.get("settings",{}).get("stall_after_seconds",900)
    for w in state.get("workers",[]):
        if w.get("state")!="RUNNING": continue
        stamp=w.get("last_progress_at")
        if not stamp: continue
        dt=datetime.fromisoformat(stamp.replace("Z","+00:00"))
        age=(now_dt-dt).total_seconds()
        if age>threshold:
            w["state"]="STALLED"
            pid=w.get("current_project_id")
            p=project(state,pid) if pid else None
            if p and p.get("assigned_worker_id")==w["id"] and p.get("status")=="RUNNING":
                p["status"]="SUSPECTED_STALL"
                p["updated_at"]=now()
            append_event({"type":"STALL_DETECTED","project_id":pid or "unknown","worker_id":w["id"],"requested_by":"supervisor","age_seconds":int(age)})
            fallback_id=w.get("fallback_worker_id")
            fallback=next((x for x in state.get("workers",[]) if x.get("id")==fallback_id),None) if fallback_id else None
            # A reservation is not proof of execution. Only a fresh, unoccupied
            # worker may receive it; owner pauses and current ownership win.
            fallback_fresh=False
            if fallback and fallback.get("last_heartbeat_at"):
                try:
                    heartbeat=datetime.fromisoformat(fallback["last_heartbeat_at"].replace("Z","+00:00"))
                    heartbeat_age=(now_dt-heartbeat).total_seconds()
                    fallback_fresh=0 <= heartbeat_age <= threshold
                except (ValueError, TypeError):
                    pass
            can_reroute=(p and p.get("assigned_worker_id")==w["id"]
                         and p.get("desired_state")=="RUNNING"
                         and fallback and fallback.get("state")=="IDLE"
                         and not fallback.get("current_project_id")
                         and fallback_fresh)
            if can_reroute:
                previous_worker=p.get("assigned_worker_id")
                p["assigned_worker_id"]=fallback["id"]
                p["status"]="WAITING"
                p["desired_state"]="RUNNING"
                p["updated_at"]=now()
                fallback["state"]="RETRYING"
                fallback["current_project_id"]=p["id"]
                append_event({"type":"REROUTE_REQUESTED","project_id":p["id"],"worker_id":fallback["id"],"previous_worker_id":previous_worker,"requested_by":"supervisor","reason":"stalled_worker"})
            else:
                blocker_id=f"stall-{w['id']}"
                attention=state.setdefault("attention",[])
                existing=next((a for a in attention if a.get("id")==blocker_id and a.get("status")=="OPEN"),None)
                if not existing:
                    attention.append({"id":blocker_id,"project_id":pid or "unknown","title":"Worker stalled without safe fallback","detail":f"Worker {w['id']} requires owner or operator recovery.","type":"RUNTIME","status":"OPEN"})
                    append_event({"type":"STALL_ESCALATED","project_id":pid or "unknown","worker_id":w["id"],"requested_by":"supervisor","blocker_id":blocker_id})
            changed=True
    if changed: save_state(state)
    return state

class Handler(SimpleHTTPRequestHandler):
    MAX_JSON_BODY=65536

    def end_headers(self):
        self.send_header("X-Content-Type-Options","nosniff")
        self.send_header("Referrer-Policy","no-referrer")
        self.send_header("Content-Security-Policy","default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; form-action 'none'")
        super().end_headers()

    def translate_path(self,path):
        parsed=unquote(urlparse(path).path)
        rel="index.html" if parsed=="/" else parsed.lstrip("/")
        app_root=APP.resolve()
        candidate=(app_root/rel).resolve()
        try:
            candidate.relative_to(app_root)
        except ValueError:
            return str(app_root/"__blocked_path__")
        return str(candidate)

    def _json(self,obj,status=200):
        body=json.dumps(obj).encode()
        self.send_response(status)
        self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",str(len(body)))
        self.send_header("Cache-Control","no-store")
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        try:
            n=int(self.headers.get("Content-Length","0"))
        except ValueError as error:
            raise ValueError("invalid Content-Length") from error
        if n<0 or n>self.MAX_JSON_BODY:
            raise ValueError("request body exceeds limit")
        return json.loads(self.rfile.read(n) or b"{}")

    def _require_api_auth(self):
        status=api_token_status(self.headers.get("Authorization"))
        if status=="AUTHORIZED":
            return True
        if status=="NOT_CONFIGURED":
            self._json({"error":"ZENTRYVA_CONTROL_TOKEN is not configured"},503)
        else:
            self._json({"error":"unauthorized"},401)
        return False

    def _require_worker_auth(self,worker_id):
        status=worker_token_status(worker_id,self.headers.get("Authorization"))
        if status=="AUTHORIZED":
            return True
        if status=="NOT_CONFIGURED":
            self._json({"error":"worker token is not configured"},503)
        else:
            self._json({"error":"unauthorized worker"},401)
        return False

    def do_GET(self):
        parsed=urlparse(self.path)
        path=parsed.path
        if path=='/api/execution/status':
            query=parse_qs(parsed.query)
            worker_id=query.get('worker_id',[''])[0]
            if not self._require_worker_auth(worker_id): return
            try:
                return self._json(worker_run_status(query.get('run_id',[''])[0],worker_id))
            except KeyError:
                return self._json({'error':'run not found'},404)
            except ValueError:
                return self._json({'error':'invalid stored evidence'},400)
        if path=="/api/state":
            if not self._require_api_auth(): return
            return self._json(supervisor_tick())
        if path=="/api/health":
            return self._json({"ok":True,"time":now()})
        if path=="/api/events":
            if not self._require_api_auth(): return
            rows=[]
            if EVENTS.exists():
                rows=[json.loads(x) for x in EVENTS.read_text(encoding="utf-8").splitlines() if x.strip()]
            return self._json(rows[-200:])
        if path=="/api/execution/pending":
            worker_id=parse_qs(parsed.query).get("worker_id",[""])[0]
            if not worker_id:
                return self._json({"error":"worker_id is required"},400)
            if not self._require_worker_auth(worker_id): return
            try:
                return self._json({"runs":pending_executions(worker_id)})
            except KeyError as e:
                return self._json({"error":str(e)},404)
        return super().do_GET()

    def do_POST(self):
        path=urlparse(self.path).path
        try:
            if path in {'/api/execution/acquire','/api/execution/pulse','/api/execution/release'}:
                payload=self._body()
                if not isinstance(payload,dict): raise ValueError('object required')
                if not self._require_worker_auth(payload.get('worker_id')): return
                operation={'/api/execution/acquire':acquire_execution,
                           '/api/execution/pulse':pulse_execution,
                           '/api/execution/release':release_execution}[path]
                return self._json(operation(payload))
            if path=="/api/control":
                if not self._require_api_auth(): return
                event,state=apply_control(self._body())
                return self._json({"event":event,"state":state},201)
            if path=="/api/heartbeat":
                payload=self._body()
                if not self._require_worker_auth(payload.get("worker_id")): return
                return self._json(apply_heartbeat(payload))
            if path=="/api/execution/request":
                if not self._require_api_auth(): return
                run,state=request_execution(self._body())
                return self._json({"run":run,"state":state},201)
            if path=="/api/execution/acknowledge":
                payload=self._body()
                if not self._require_worker_auth(payload.get("worker_id")): return
                run,state=acknowledge_execution(payload)
                return self._json(worker_mutation_view(run,state),200)
            if path=="/api/evidence":
                payload=self._body()
                if not self._require_worker_auth(payload.get("worker_id")): return
                reference,record=store_evidence(payload)
                return self._json({"evidence_ref":reference,"record":record},201)
            if path=="/api/execution/complete":
                payload=self._body()
                if not self._require_worker_auth(payload.get("worker_id")): return
                run,state=complete_execution(payload)
                if run.get('protocol')=='cooperative-v1':
                    return self._json(worker_run_status(run['id'],run['worker_id']))
                return self._json(worker_mutation_view(run,state),200)
            return self._json({"error":"not found"},404)
        except KeyError as e: return self._json({"error":str(e)},404)
        except (ValueError,json.JSONDecodeError) as e: return self._json({"error":str(e)},400)

    def log_message(self,fmt,*args):
        print("%s - %s" % (self.log_date_time_string(),fmt%args))

if __name__=="__main__":
    DATA.mkdir(exist_ok=True)
    EVENTS.touch(exist_ok=True)
    port=int(os.environ.get("PORT","8080"))
    print(f"Zentryva Command Center: http://127.0.0.1:{port}")
    ThreadingHTTPServer(("0.0.0.0",port),Handler).serve_forever()
