# Execution Provider Contract

## Purpose
The Controller remains Zentryva's orchestration authority. An execution provider is a replaceable runtime used to perform a bounded unit of work.

Providers may include OpenAI Agents SDK, Codex, n8n, Mindra, CrewAI, Relevance AI, or a custom/local runtime. Provider choice must never become part of project identity.

## Controller -> provider request
A provider request contains:
- `run_id`
- `project_id`
- `provider_id`
- `action`
- optional `input`
- whether owner approval is required
- optional checkpoint/evidence references

The Controller records the request before any provider action occurs.

## Provider -> Controller result
A provider returns:
- `run_id`
- `status`: COMPLETE or FAILED
- optional `evidence_ref`
- optional summary
- provider-specific metadata that does not contain secrets

## Owner-gate behavior
1. If a request requires owner approval, the run enters `WAITING_FOR_OWNER`.
2. The Command Center creates an Attention Required item tied to the run.
3. APPROVAL transitions the run to `APPROVED` and the project back to a runnable desired state.
4. REJECTION transitions the run to `REJECTED`; it must not execute.
5. Approval is auditable and independent of the provider.

## Safety invariants
- The provider cannot self-approve owner-gated actions.
- No provider may bypass ReleaseProof or Quality & Reliability.
- Secrets must be referenced, never copied into event payloads.
- Production publication, destructive changes, spending, legal acceptance, and credential changes remain owner-gated.
- Provider failure must not erase the last recoverable checkpoint.
- Provider replacement must not require rewriting project records.

## First vertical slice
The first slice uses a MOCK provider to prove:
Command Center -> Controller -> execution request -> owner gate -> approval -> completion -> evidence log.

A real OpenAI Agents SDK adapter can replace MOCK after the contract is proven.
