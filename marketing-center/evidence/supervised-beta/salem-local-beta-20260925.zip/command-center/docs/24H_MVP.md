# 24-Hour MVP Build Plan

## Definition of done
A local/staging graphical console can display registered projects/workers, relationships, state and blockers; accept safe control signals; record custom instructions; detect stale workers; and preserve an auditable event trail.

It must never claim control of a ChatGPT account unless an adapter/runtime actually consumes its signals.

## 0–4h — core contracts + UI shell
- project, worker, module and control-event schemas
- dashboard shell and navigation
- project/worker/status cards
- relationship/dependency storage

## 4–10h — operating loop
- project detail
- Attention Required inbox
- pause/resume/retry requests
- custom instruction submission
- event timeline

## 10–16h — supervisor + router hooks
- heartbeat and last-progress timestamps
- stall policy and recovery-request state
- worker capability registry
- router recommendation/assignment interface
- checkpoint/handoff records

## 16–22h — first real adapter
- connect one authorized worker/runtime
- verify command receipt + status return
- blocker -> approval -> resume round trip
- failure/retry evidence

## 22–24h — independent evidence
- regression and negative tests
- limitations documented
- candidate packaged for independent QA/ReleaseProof

## Explicitly deferred
Full multi-provider autonomous routing, arbitrary ChatGPT-session remote control, polished graph canvas, external PM/CRM synchronization and production deployment.
