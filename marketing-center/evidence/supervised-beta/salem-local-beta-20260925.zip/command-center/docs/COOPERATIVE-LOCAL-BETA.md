# Cooperative local worker protocol

Candidate branch worker/salem-local-control-20260925 extends development base
6c50292cf91fb4ea94f08e833e899d555290b714. No production deployment or main merge.

The owner queues protocol `cooperative-v1`. The worker authenticates with its own
token and reads `/api/execution/status?worker_id=...&run_id=...`. Responses expose
only the selected worker's run, its runnable flag and terminal result evidence.
Legacy acknowledgement/completion responses now project only the associated
project/provider control fields rather than returning global state.

`POST /api/execution/acquire` accepts worker_id, run_id, session_id (random 128-bit
hex) and pending receipt_ref/checkpoint_ref. An active session prevents takeover.
Only a hash of the capability is persisted. A new session gets a generation and
30-second renewable lease. Wall and monotonic deadlines both apply; an expired
capability cannot revive after a clock rollback. A fresh server process epoch
invalidates previous sessions, permitting explicit recovery.

`POST /api/execution/pulse` with the same session fields checks lease and ownership,
renews the lease, and reports runnable=false on pause, reassignment or provider
disable. `POST /api/execution/release` voluntarily relinquishes the lease. These
endpoints never change the owner's desired state. Resume uses the existing owner
RESUME_REQUESTED event. Receipt/checkpoint requirements and owner gates remain.

Result evidence and completion require a valid current session and runnable
project; evidence is bound to the session generation. Old result evidence cannot
finish a newly recovered attempt. Lost mutation responses are reconciled through
status, never blindly retried. Event history records acquisition generations.

Qualification boundary: one server process, isolated local fixture state, trusted
bundled pure stages, ephemeral loopback listener. Use a custom loopback launcher;
the legacy server.py main still binds all interfaces and is not the beta launcher.
No arbitrary provider preemption, automatic service installation, multi-process
state store, crash-atomic state/event transaction or live publishing is certified.
The JSON state backend is atomically replaced but not a transactional event store.
