# Stall reservation safety — 2026-09-20

Status: builder remediation evidence; HOLD for independent ReleaseProof and live adapter integration.

## Source identity
Base: d9c487e168f4cc1ceeb94f87c0210da1346a3e39 (PR #4).
Tested code commit: ab634f5a2ce4a08efd14937715cec2523d9bb058.
Branch: fix/stall-reservation-safety-20260920.
Frozen PR #1 and all pre-existing branches were left unchanged.

Six fetched Git blob identities match the tested Windows and Linux source:
- tests/test_core.py: 29babbf0d6516ecbf5453fbcd8e2e6e7cda0a2b5
- tests/test_stall_safety.py: 119bf3bae295b481b936bc9d5bcad63059b0de63
- app/app.js: 65d14e7ef01bc4773fd420165c69dd4a946b028b
- tests/test_execution_provider.py: 3381b1157094cc56a1c7d30a879501d4ca9ca916
- tests/test_stall_recovery.py: 49da5a48136d3fa4575579b53cbfaf0744891c4c
- server.py: c930d401094fa09e9d51f7768a5750c2eaf4307b

## Findings and corrections
- Busy fallback workers could lose an unrelated assignment. Require IDLE with no current project.
- A fallback with no heartbeat was treated as healthy. Require a parseable, timezone-aware heartbeat within the configured stall threshold, rejecting future timestamps.
- Stall handling could override PAUSED desired state. Require RUNNING desired state and matching current worker ownership.
- Reroute code previously set RUNNING and advanced progress without execution. Reserve as RETRYING / project WAITING and emit REROUTE_REQUESTED. Do not manufacture progress.
- Old worker references no longer change the status of a project assigned elsewhere.

Regression tests cover missing, stale, malformed, timezone-naive and future heartbeats, busy/occupied workers, pauses, changed ownership, and idempotent reservation.

## Executed results
Original five-file source snapshot: 16 tests PASS on Linux and Windows; JS syntax PASS.
Remediation six-file source snapshot: 22 tests PASS on Linux and Windows; JS syntax PASS.
Linux Python 3.12.14, Node v24.19.0; Windows Python 3.14.7, Node v24.21.0.
Strict command: python -W error::ResourceWarning -m unittest discover -s tests -v
Syntax command: node --check app/app.js
Linux compile: python3 -m compileall -q server.py tests, exit 0.
These are selected source-file snapshots, not full repository checkouts or complete UI/packaging tests.

## Exploratory probe accounting
An exploratory five-check script was also run. Original snapshot: 0/5 expected safeguards observed; remediation: 3/5.
Three confirmed recovery defects are fixed above.
One remaining completion check demonstrates the known lifecycle gap: a queued run can be marked COMPLETE without receipt/checkpoint/evidence. No adapter execution is proven.
The other exploratory check used approval_mode=OWNER. Subsequent schema inspection showed OWNER is not a supported enum (CONTROLLER/PROVIDER/HYBRID are supported). Exclude that check from defect counts; it is not evidence that a valid owner-policy configuration was bypassed.
The exploratory script's nonzero exit is preserved and must not be confused with the passing regression suite.

## Remaining work / next executable action
1. Implement a bounded, isolated local adapter with explicit receipt, checkpoint and acknowledgement; enforce lifecycle and worker/provider identity before accepting completion.
2. Test a real safe adapter round trip, crash/retry behavior and acknowledgement after reservation. Do not call a reservation executed.
3. Current read-modify-write operations lock individual file accesses, not complete transactions; concurrency safety needs remediation before multiple adapters.
4. A shared bearer token does not establish worker-versus-owner authorization; provider calls must not be able to self-approve owner gates.
5. Perform visual browser QA and independently reproduce the candidate in ReleaseProof. No GO is issued here.
6. Controller v0.81.0.post1 manifestfix remains separately identified by SHA-256 879ef4e2ca07b33c9dca2fdd3f4d8bcf5307d145c259e0ca9e13f76047c2cbe5. Its recorded 725/725 Windows and Linux results and Richard-reported GO do not certify this Command Center change. No Controller artifact was altered.

## Linux actual regression output
```text
test_api_token_comparison (test_core.CoreTests.test_api_token_comparison) ... ok
test_api_token_is_deny_by_default (test_core.CoreTests.test_api_token_is_deny_by_default) ... ok
test_approval_resolves_attention_persistently (test_core.CoreTests.test_approval_resolves_attention_persistently) ... ok
test_instruction_is_audited (test_core.CoreTests.test_instruction_is_audited) ... ok
test_invalid_worker_state_rejected (test_core.CoreTests.test_invalid_worker_state_rejected) ... ok
test_path_traversal_is_contained (test_core.CoreTests.test_path_traversal_is_contained) ... ok
test_pause_persists (test_core.CoreTests.test_pause_persists) ... ok
test_unknown_heartbeat_project_rejected (test_core.CoreTests.test_unknown_heartbeat_project_rejected) ... ok
test_unknown_project_rejected (test_core.CoreTests.test_unknown_project_rejected) ... ok
test_unsupported_control_rejected (test_core.CoreTests.test_unsupported_control_rejected) ... ok
test_duplicate_run_and_disabled_provider_are_rejected (test_execution_provider.ExecutionProviderTests.test_duplicate_run_and_disabled_provider_are_rejected) ... ok
test_non_gated_request_and_completion_are_audited (test_execution_provider.ExecutionProviderTests.test_non_gated_request_and_completion_are_audited) ... ok
test_owner_gate_blocks_completion_until_approval (test_execution_provider.ExecutionProviderTests.test_owner_gate_blocks_completion_until_approval) ... ok
test_rejection_is_terminal (test_execution_provider.ExecutionProviderTests.test_rejection_is_terminal) ... ok
test_configured_healthy_fallback_is_rerouted (test_stall_recovery.StallRecoveryTests.test_configured_healthy_fallback_is_rerouted) ... ok
test_missing_fallback_escalates_once (test_stall_recovery.StallRecoveryTests.test_missing_fallback_escalates_once) ... ok
test_busy_worker_keeps_its_assignment (test_stall_safety.StallSafetyTests.test_busy_worker_keeps_its_assignment) ... ok
test_idle_but_assigned_worker_is_not_available (test_stall_safety.StallSafetyTests.test_idle_but_assigned_worker_is_not_available) ... ok
test_missing_stale_invalid_and_future_heartbeats_are_rejected (test_stall_safety.StallSafetyTests.test_missing_stale_invalid_and_future_heartbeats_are_rejected) ... ok
test_old_worker_cannot_reassign_current_owner (test_stall_safety.StallSafetyTests.test_old_worker_cannot_reassign_current_owner) ... ok
test_owner_pause_is_preserved (test_stall_safety.StallSafetyTests.test_owner_pause_is_preserved) ... ok
test_reservation_does_not_fabricate_progress_or_repeat (test_stall_safety.StallSafetyTests.test_reservation_does_not_fabricate_progress_or_repeat) ... ok

----------------------------------------------------------------------
Ran 22 tests in 0.022s

OK

```

## Windows actual captured identity and regression output
The capture initially labels the source UNCOMMITTED because testing began before repository identity binding. All six blob hashes were subsequently verified against code commit ab634f5a2ce4a08efd14937715cec2523d9bb058.
```text
Process started with PID 95040 (shell: powershell.exe)
Initial output:
{
  "commit": "UNCOMMITTED remediation based on d9c487e168f4cc1ceeb94f87c0210da1346a3e39",
  "runtime": "3.14.7 (tags/v3.14.7:823f032, Aug  5 2026, 10:51:32) [MSC v.1944 64 bit (AMD64)]",
  "platform": "Windows-11-10.0.26200-SP0",
  "identity": [
    {
      "path": "server.py",
      "git_blob": "c930d401094fa09e9d51f7768a5750c2eaf4307b",
      "sha256": "c94bacf3c7b932260c3bda474be1257d769bdd9054992a97447e62d3e0ca1777"
    },
    {
      "path": "tests/test_core.py",
      "git_blob": "29babbf0d6516ecbf5453fbcd8e2e6e7cda0a2b5",
      "sha256": "367b8cfd457d855a54699ba849ecb72ce977cb63132ef06e369807860e7c75d7"
    },
    {
      "path": "tests/test_execution_provider.py",
      "git_blob": "3381b1157094cc56a1c7d30a879501d4ca9ca916",
      "sha256": "42096a583c17b9592bb126d03965ad19bba4d93dcaf23a1e4a0f3545b1cc4702"
    },
    {
      "path": "tests/test_stall_recovery.py",
      "git_blob": "49da5a48136d3fa4575579b53cbfaf0744891c4c",
      "sha256": "3c0333811c7a1a122da4c11ed7f8884df07f45496f483e68e365ffb5471fde21"
    },
    {
      "path": "tests/test_stall_safety.py",
      "git_blob": "119bf3bae295b481b936bc9d5bcad63059b0de63",
      "sha256": "08e9d782675f6cb96f85bb458fd35cd72b6ffbe3f6f54e3d484e4ce3a71a77c2"
    },
    {
      "path": "app/app.js",
      "git_blob": "65d14e7ef01bc4773fd420165c69dd4a946b028b",
      "sha256": "a5a39e72fb32eec0705eb4c4fd90113220fe861c53b4ed3b5354e187fb48d66e"
    }
  ],
  "commands": [
    {
      "name": "baseline",
      "command": [
        "C:\\Python314\\python.exe",
        "-W",
        "error::ResourceWarning",
        "-m",
        "unittest",
        "discover",
        "-s",
        "tests",
        "-v"
      ],
      "exit_code": 0
    },
    {
      "name": "syntax",
      "command": [
        "node",
        "--check",
        "app/app.js"
      ],
      "exit_code": 0
    },
    {
      "name": "probes",
      "command": [
        "C:\\Python314\\python.exe",
        "probe_release_gates.py"
      ],
      "exit_code": 1
    }
  ]
}
test_api_token_comparison (test_core.CoreTests.test_api_token_comparison) ... ok
test_api_token_is_deny_by_default (test_core.CoreTests.test_api_token_is_deny_by_default) ... ok
test_approval_resolves_attention_persistently (test_core.CoreTests.test_approval_resolves_attention_persistently) ... ok
test_instruction_is_audited (test_core.CoreTests.test_instruction_is_audited) ... ok
test_invalid_worker_state_rejected (test_core.CoreTests.test_invalid_worker_state_rejected) ... ok
test_path_traversal_is_contained (test_core.CoreTests.test_path_traversal_is_contained) ... ok
test_pause_persists (test_core.CoreTests.test_pause_persists) ... ok
test_unknown_heartbeat_project_rejected (test_core.CoreTests.test_unknown_heartbeat_project_rejected) ... ok
test_unknown_project_rejected (test_core.CoreTests.test_unknown_project_rejected) ... ok
test_unsupported_control_rejected (test_core.CoreTests.test_unsupported_control_rejected) ... ok
test_duplicate_run_and_disabled_provider_are_rejected (test_execution_provider.ExecutionProviderTests.test_duplicate_run_and_disabled_provider_are_rejected) ... ok
test_non_gated_request_and_completion_are_audited (test_execution_provider.ExecutionProviderTests.test_non_gated_request_and_completion_are_audited) ... ok
test_owner_gate_blocks_completion_until_approval (test_execution_provider.ExecutionProviderTests.test_owner_gate_blocks_completion_until_approval) ... ok
test_rejection_is_terminal (test_execution_provider.ExecutionProviderTests.test_rejection_is_terminal) ... ok
test_configured_healthy_fallback_is_rerouted (test_stall_recovery.StallRecoveryTests.test_configured_healthy_fallback_is_rerouted) ... ok
test_missing_fallback_escalates_once (test_stall_recovery.StallRecoveryTests.test_missing_fallback_escalates_once) ... ok
test_busy_worker_keeps_its_assignment (test_stall_safety.StallSafetyTests.test_busy_worker_keeps_its_assignment) ... ok
test_idle_but_assigned_worker_is_not_available (test_stall_safety.StallSafetyTests.test_idle_but_assigned_worker_is_not_available) ... ok
test_missing_stale_invalid_and_future_heartbeats_are_rejected (test_stall_safety.StallSafetyTests.test_missing_stale_invalid_and_future_heartbeats_are_rejected) ... ok
test_old_worker_cannot_reassign_current_owner (test_stall_safety.StallSafetyTests.test_old_worker_cannot_reassign_current_owner) ... ok
test_owner_pause_is_preserved (test_stall_safety.StallSafetyTests.test_owner_pause_is_preserved) ... ok
test_reservation_does_not_fabricate_progress_or_repeat (test_stall_safety.StallSafetyTests.test_reservation_does_not_fabricate_progress_or_repeat) ... ok

----------------------------------------------------------------------
Ran 22 tests in 0.128s

OK



[executed on device: MTI (378ac1e3-f6b2-4295-97e5-6eb023a77df7)]
```
