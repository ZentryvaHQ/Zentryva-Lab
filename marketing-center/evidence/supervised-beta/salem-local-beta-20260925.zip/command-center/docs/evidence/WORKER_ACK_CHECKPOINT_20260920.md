# Worker acknowledgement and checkpoint evidence — 2026-09-20

Status: builder evidence. Independent ReleaseProof remains required.

## Subject
- Repository: `ZentryvaHQ/Zentryva-Command-Center-Core`
- Base: PR #6 commit `c7b39db85cfeb879e973308c4f8be03b038110e7`
- Tested code commit: `bf9118ef5dd810b7bd5068b6bf7b0cb17054943d`
- Branch: `feat/worker-ack-checkpoint-20260920`
- Frozen PR #1 and Controller artifacts were not modified.

## Implemented behavior
- Controller requests bind to a known worker assigned to the project.
- Workers poll only their own pending runs with a worker-scoped token.
- A worker must record receipt and checkpoint references before execution becomes RUNNING.
- Completion requires the same worker identity, acknowledgement state, and a nonempty evidence reference.
- Owner and worker credentials are separate. Tokens remain environment-only.
- All in-process state-changing operations are serialized to prevent lost updates between concurrent HTTP handlers.
- Forty simultaneous instruction mutations are exercised in the regression suite.

## HTTP lifecycle exercised
1. Owner request accepted: HTTP 201 / QUEUED.
2. Owner token denied on worker queue: HTTP 401.
3. Assigned worker reads its queue: HTTP 200.
4. Receipt and checkpoint acknowledgement accepted: HTTP 200 / RUNNING.
5. Completion without evidence rejected: HTTP 400.
6. Completion with evidence accepted: HTTP 200 / COMPLETE.
7. Event order verified: EXECUTION_REQUESTED, EXECUTION_ACKNOWLEDGED, EXECUTION_COMPLETED.

This is an isolated local adapter harness. It performs no production or destructive action.

## Linux verification
- Python 3.12.14; Node v24.19.0.
- `python3 -m compileall -q server.py tests`: exit 0.
- `python3 -W error::ResourceWarning -m unittest discover -s tests -v`: 29 tests, OK, exit 0.
- Regression output SHA-256: `9ace7e1648910c5924bc4d6ce9284ae3efc2f60877328276181636903882dbe7`.
- `node --check app/app.js`: exit 0.

## Windows verification
- Device: MTI; Windows 11 build 26200; Python 3.14.7; Node v24.21.0.
- Eight tested source blobs were reconstructed from their Git blob identities.
- Compile: exit 0.
- Strict regression: 29 tests, OK, exit 0.
- Windows regression output SHA-256: `1e6a7c4caa9f2e3ed6502f28860b8aee5073b6d4e3828ddcfad87637ddacab77`.
- JavaScript syntax: exit 0.

Tested Git blobs:
- `server.py`: `5eb592de7c235dd245ace125845b2a8c9eeec1ed`
- `app/app.js`: `65d14e7ef01bc4773fd420165c69dd4a946b028b`
- `tests/test_core.py`: `29babbf0d6516ecbf5453fbcd8e2e6e7cda0a2b5`
- `tests/test_execution_provider.py`: `37701e0e9fe16ac5474bd0978b7038404ab761fa`
- `tests/test_stall_recovery.py`: `49da5a48136d3fa4575579b53cbfaf0744891c4c`
- `tests/test_stall_safety.py`: `119bf3bae295b481b936bc9d5bcad63059b0de63`
- `tests/test_worker_lifecycle.py`: `8327bbf67bbb45021888368d0ea8647c398ebdfe`
- `tests/test_http_worker_roundtrip.py`: `3620afae94a9dc346ca7b4b1ea41db2062e65464`

## Remaining boundaries
- State and event persistence are protected within one process. Multi-process or multi-host execution needs a transactional database and durable event outbox.
- Receipt, checkpoint and evidence references are recorded but their referenced bytes need a durable evidence store and content verification.
- The visual interface still needs browser viewport and interaction verification.
- Independent ReleaseProof must reproduce the exact candidate and issue GO, HOLD, or NO-GO.
- Controller `v0.81.0.post1` remains a separate ReleaseProof-GO artifact reported by Richard; this work does not modify or recertify it.


## Security hardening follow-up
Exact branch code commit before this evidence-only update: `063786af1566ff77a47eb705d442bd154d6d7def`.

A review found that dynamic project and blocker identifiers were interpolated into inline click handlers. That could permit stored browser-script execution if an identifier contained crafted characters. The UI now uses escaped data attributes and one controlled event dispatcher. A restrictive Content Security Policy is enforced in the document and response headers. JSON request bodies are capped at 65,536 bytes, API responses are no-store, and MIME sniffing is disabled.

Verification:
- Six changed Git blobs match the locally tested bytes.
- Linux strict suite: 32 tests, OK; compile and JavaScript syntax exit 0.
- GitHub Actions run 35501622147 completed successfully for exact commit `063786af1566ff77a47eb705d442bd154d6d7def`, including compile, strict regression, JavaScript syntax, and JSON validation.
- Windows had already passed the 29-test worker lifecycle at `bf9118ef5dd810b7bd5068b6bf7b0cb17054943d`. The later UI/security additions have not been rerun on Windows.

Visual QA status: HOLD. Browser automation could not be completed in this run because the disposable Linux browser binary was unavailable and its download was blocked by network policy. MTI remained reachable, but its file-write service returned an automatic approval-review failure caused by exhausted workspace credits. No screenshot or interaction pass is claimed.

Next independent action: run the exact branch head in a browser at desktop and tablet widths, verify dashboard navigation, project dialog, attention controls, relationship view, no horizontal overflow, no browser console/CSP errors, and attach screenshots plus the exact commit identity. Then reproduce the security and worker-lifecycle tests and issue GO, HOLD, or NO-GO.
