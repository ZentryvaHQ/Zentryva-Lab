# Content-addressed execution evidence — 2026-09-20

## Scope and ancestry

- Repository: `ZentryvaHQ/Zentryva-Command-Center-Core`
- Branch: `feat/content-addressed-evidence-20260920`
- Exact base: `c68e11a4368f37e56a6b640609176c0b11a80dc7` (draft PR #7 head)
- Frozen PR #1 was not modified.

This slice closes a gap in the worker lifecycle: receipt, checkpoint, and result references previously could be arbitrary nonempty strings. A run now consumes only evidence objects that the assigned worker stored through the authenticated API and that remain byte-identical to their SHA-256 references.

## Behavior

- `POST /api/evidence` accepts a nonempty evidence object from the run's authenticated worker.
- Evidence is canonical JSON stored under `data/evidence/<sha256>.json` using a unique temporary file, `fsync`, and atomic replacement.
- References use `sha256:<64 lowercase hex>`.
- Receipt and checkpoint evidence may be created only while the run is pending.
- Result evidence may be created only after acknowledgement while the run is running.
- Acknowledgement and completion verify the referenced bytes and bind each record to its expected kind, run, and worker.
- Missing, malformed, wrong-kind, cross-run, cross-worker, and hash-mismatched records are rejected.

## Local verification

Environment:

```text
Linux x86_64
Python 3.12
Node.js available for syntax validation
```

Commands:

```text
python3 -m compileall -q server.py tests
python3 -W error::ResourceWarning -m unittest discover -s tests -v
node --check app/app.js
jq empty data/state.json
```

Observed summary:

```text
Ran 34 tests in 1.068s
OK
compileall exit: 0
node --check exit: 0
state JSON validation exit: 0
```

The authenticated HTTP regression performed this sequence:

```text
execution request                         201
pending queue with owner token            401
pending queue with assigned-worker token  200
evidence write with owner token           401
receipt evidence write                    201
checkpoint evidence write                 201
execution acknowledgement                 200
completion without result evidence        400
result evidence write                     201
evidenced completion                      200
```

## Tested source identity

| Path | Git blob |
|---|---|
| `server.py` | `6f77885972a98e89cc5e81e13d1a9f10eb85e689` |
| `tests/test_worker_lifecycle.py` | `001ba86a9c6a30ab64fd454e52e648262f8d4133` |
| `tests/test_execution_provider.py` | `7a1644114cff16a8bc238ff07fe0c5574ca0b5e2` |
| `tests/test_http_worker_roundtrip.py` | `285ee688ae09e59392eca6c26c209144aff59650` |
| `docs/WORKER_ADAPTER.md` | `c7b590e7c90cf380294c2d183ea66e9c3c2b515e` |
| `README.md` | `8f99c8a02f477828c7e19d79febfdb966f2b8881` |

The remote GitHub content API returned these same blob identities after each write.

## Remote exact-head verification

- Commit: `8a4420a5489c6e0e134ea9c4103b358e79c86faa`
- GitHub Actions run: `35504608612`
- Workflow: `Command Center verification`
- Job: `verify`
- Result: `success`

Successful steps included runtime identity, Python compilation, the strict regression suite, JavaScript syntax, and JSON validation.

## Windows exact-code verification

- Code commit: `cbcfbefc0331f38d6c5c991d7e08ee7c05db0a2b`
- Device: MTI
- Platform: `Microsoft Windows NT 10.0.26200.0`
- Python: `3.14.7`
- Node.js: `v24.21.0`
- Transfer archive SHA-256: `32f444d0903c0479c0150fbc4d4c27c94e1fce18334e79db4d90a9bb2116d4e2`
- Evidence record SHA-256: `61779b7b3cbbbd9fe4f87a84adbcdbb53d069967a69ed72d0c64798dfac1a10e`
- Test transcript SHA-256: `1b9cf6113b9dea092cb74c461878efe6e123d98425be5d47cd52c89d2adae449`

Observed summary:

```text
COMPILE_EXIT=0
Ran 34 tests in 1.512s
OK
TEST_EXIT=0
JS_EXIT=0
JSON_EXIT=0
```

Windows `git hash-object` returned the same six tested blob identities listed above. The source was expanded and executed only in `C:\Users\festg\Documents\Zentryva_QA_20260920_content_evidence_cbcfbef`; no existing working tree or production service was modified.

## Boundaries and holds

- This is builder evidence, not independent ReleaseProof certification.
- The evidence store is durable on the local filesystem, but state/event transactions remain single-process. Multi-process or multi-host operation still requires a transactional database and durable outbox.
- No production service, adapter, credential, merge, deployment, or frozen candidate was changed.
- The visual application files are unchanged by this backend slice. The previously recorded exact-head desktop/tablet interaction pass remains outstanding.
- The remaining release gates are the existing exact-head visual viewport/interaction pass, multi-process transactional persistence, and independent ReleaseProof adjudication.
- Controller `v0.81.0.post1` remains a separate ReleaseProof-GO subject and was not modified or retested.
