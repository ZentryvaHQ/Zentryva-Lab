# Worker Adapter Protocol

A worker adapter is the only component allowed to turn a Command Center control request into an action in an execution environment.

## Poll loop
1. Register worker identity/capabilities.
2. Send heartbeat to `POST /api/heartbeat`.
3. Read assigned project desired state and unacknowledged control events.
4. Validate that the requested action is within the adapter's allowlist.
5. Execute only safe, authorized actions.
6. Write an acknowledgement/result event with evidence reference.
7. Update progress timestamp only when meaningful progress occurred.

## Required safety behavior
- Never interpret absence of a heartbeat as permission to kill a process.
- Never execute destructive, spending, legal, production-publication or credential-changing actions without the corresponding owner gate.
- A `PAUSE_REQUESTED` event is a request until the worker acknowledges a safe checkpoint.
- Preserve the last recoverable checkpoint before retry/reroute.
- Do not copy secrets into events, logs, prompts or handoff artifacts.

## Provider/account neutrality
`provider` and `environment` are worker metadata. Projects bind to capabilities, not to a specific ChatGPT account. A ChatGPT browser conversation is not remotely controllable merely because a worker record exists; a real authorized adapter must bridge that environment.


## Authenticated lifecycle
The owner/controller queues work with the control token and binds the run to an assigned worker. Each adapter uses its own bearer token from the `ZENTRYVA_WORKER_TOKENS` JSON environment mapping; token values never belong in state, events, evidence, or source.

1. Poll `GET /api/execution/pending?worker_id=<id>` with the worker token.
2. POST `/api/evidence` with `kind: "receipt"` and the adapter receipt object.
3. Create a recoverable checkpoint, then POST it to `/api/evidence` with `kind: "checkpoint"`.
4. POST `/api/execution/acknowledge` with the returned content-addressed `receipt_ref` and `checkpoint_ref`.
5. Execute the bounded allowlisted action.
6. POST the result object to `/api/evidence` with `kind: "result"`.
7. POST `/api/execution/complete` with the same worker identity, terminal status, and returned result `evidence_ref`.

The server stores evidence as immutable canonical JSON under `data/evidence`, returns a `sha256:<64 lowercase hex>` reference, and verifies the content hash plus kind/run/worker binding every time the reference is consumed. It rejects missing, malformed, cross-run, cross-worker, wrong-kind, or tampered evidence. A reservation remains pending until the adapter acknowledges it.

Example evidence request body:

```json
{
  "run_id": "run-123",
  "worker_id": "business-main",
  "kind": "receipt",
  "evidence": {
    "remote_receipt_id": "adapter-456"
  }
}
```

Example PowerShell configuration (use private values locally):

```powershell
$env:ZENTRYVA_WORKER_TOKENS = '{"business-main":"replace-private-value"}'
```

## Concurrency boundary
In-process state mutations are serialized to prevent lost updates between concurrent HTTP handlers. This MVP remains a single-process service; multi-process or multi-host operation requires a transactional database and durable event outbox.
