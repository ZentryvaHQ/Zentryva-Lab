# Zentryva Operations Console — Core Architecture

## Goal
One graphical control plane for Zentryva projects and workers regardless of provider, account, or runtime.

## Core services
1. Project Graph — projects, parent/child relationships, dependencies and ownership.
2. Project State — priority, status, blocker, checkpoint and evidence references.
3. Worker Registry — capabilities and availability; account/provider is metadata, not identity.
4. Router Contract — selects an eligible worker/model by capability, priority, availability, policy and cost.
5. Execution Supervisor — heartbeat, progress lease, stall detection, retry/recover/reroute/escalate.
6. Control Inbox — owner approvals and exceptions.
7. Artifact/Handoff Contract — provider-neutral checkpoints and evidence.
8. Event/Audit Log — append-only operational history.
9. Module Registry — new Zentryva systems plug into the same contracts.

## Keep these responsibilities separate
- Command Center: visual/control plane.
- Controller: orchestration/execution engine. The GUI does not duplicate it.
- Router: assignment decision. It is not a second Controller.
- Corporate Memory: durable knowledge/provenance. Operational state references it rather than copying it.
- Quality & Reliability: verification policy and test evidence.
- ReleaseProof: independent certification; builders cannot self-certify.
- Blocker Resolution: owner-gated decisions surfaced through the Control Inbox.

## MVP UI
Dashboard, Projects, Project Detail, Attention Required, Workers, activity timeline, dependency summary and natural-language instruction box.

## Later modules
Rich dependency graph canvas, drag/drop workflow authoring, provider cost optimization, Monday/Asana/HubSpot sync, advanced analytics and mobile-specific UX.
