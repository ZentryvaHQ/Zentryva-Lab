from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
import os
import uuid
from typing import Callable, Protocol

from transactional_store import SQLiteStateOutbox


class StateBackend(Protocol):
    def load_state(self) -> dict: ...
    def mutate(
        self,
        mutator: Callable[[dict], dict | None],
        *,
        event_type: str,
        event_payload: dict,
        event_id: str | None = None,
    ) -> tuple[dict, int, object]: ...


@dataclass(frozen=True)
class FileEventRecord:
    event_id: str
    event_type: str
    payload: dict


class JsonFileStateBackend:
    """Compatibility backend for the existing JSON state path.

    This preserves current behavior and remains the default backend. It is
    intended for single-process/local use only.
    """

    def __init__(self, state_path: str | Path, events_path: str | Path):
        self.state_path = Path(state_path)
        self.events_path = Path(events_path)

    def load_state(self) -> dict:
        with self.state_path.open("r", encoding="utf-8") as file:
            state = json.load(file)
        if not isinstance(state, dict):
            raise RuntimeError("state document must be an object")
        return state

    def _write_state(self, state: dict) -> None:
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.state_path.with_suffix(self.state_path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8") as file:
            json.dump(state, file, indent=2)
            file.write("\n")
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary, self.state_path)

    def _append_event(self, event: dict) -> None:
        self.events_path.parent.mkdir(parents=True, exist_ok=True)
        with self.events_path.open("a", encoding="utf-8") as file:
            file.write(json.dumps(event, separators=(",", ":")) + "\n")
            file.flush()
            os.fsync(file.fileno())

    def mutate(
        self,
        mutator,
        *,
        event_type: str,
        event_payload: dict,
        event_id: str | None = None,
    ):
        if not callable(mutator):
            raise ValueError("mutator must be callable")
        if not str(event_type).strip():
            raise ValueError("event_type is required")
        if not isinstance(event_payload, dict):
            raise ValueError("event_payload must be an object")

        state = self.load_state()
        working = json.loads(json.dumps(state))
        result = mutator(working)
        next_state = working if result is None else result
        if not isinstance(next_state, dict):
            raise ValueError("mutator must return an object or None")

        chosen_event_id = event_id or str(uuid.uuid4())
        event = {"id": chosen_event_id, "type": event_type, **event_payload}
        self._write_state(next_state)
        self._append_event(event)
        return (
            next_state,
            0,
            FileEventRecord(chosen_event_id, event_type, dict(event_payload)),
        )


class SQLiteStateBackend:
    def __init__(
        self,
        database_path: str | Path,
        *,
        initial_state: dict | None = None,
    ):
        self.store = SQLiteStateOutbox(database_path)
        self.store.initialize(initial_state)

    def load_state(self) -> dict:
        state, _version = self.store.read_state()
        return state

    def mutate(
        self,
        mutator,
        *,
        event_type: str,
        event_payload: dict,
        event_id: str | None = None,
    ):
        return self.store.mutate(
            mutator,
            event_type=event_type,
            event_payload=event_payload,
            event_id=event_id,
        )


def build_state_backend(
    *,
    data_dir: str | Path,
    mode: str | None = None,
    initial_state: dict | None = None,
) -> StateBackend:
    data_dir = Path(data_dir)
    selected = (
        mode or os.environ.get("ZENTRYVA_STATE_BACKEND", "json")
    ).strip().lower()
    if selected == "json":
        return JsonFileStateBackend(
            data_dir / "state.json",
            data_dir / "events.jsonl",
        )
    if selected == "sqlite":
        return SQLiteStateBackend(
            data_dir / "state.sqlite3",
            initial_state=initial_state,
        )
    raise ValueError("ZENTRYVA_STATE_BACKEND must be 'json' or 'sqlite'")
