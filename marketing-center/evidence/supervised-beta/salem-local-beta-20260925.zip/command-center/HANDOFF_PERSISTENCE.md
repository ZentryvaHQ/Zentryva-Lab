# Command Center Persistence Candidate — Temporary Worker Handoff

## Scope

CC-PERSIST-001 introduces a standalone SQLite transactional state store with a durable
outbox. It is intentionally **not wired into server.py** yet.

The candidate uses one SQLite transaction to read the latest state document, apply one
mutation, write the next state version, and insert the corresponding outbox record before
COMMIT. Each operation opens an independent SQLite connection and uses WAL plus
`BEGIN IMMEDIATE` to serialize writers at the database boundary.

## Exact candidate

- Branch: `worker/command-center-sqlite-outbox-20260921`
- Base checkpoint: `ff69824cec7a3942e92df5c8112d9ac38a2a288d`
- Code/test head before evidence-only commits: `4c668ae107d498eb7c0de1f32228a63ed3507984`
- `transactional_store.py` Git blob: `31d52218c661c426473181922cdab3d3ab21078b`
- `tests/test_transactional_store.py` Git blob: `5d8d74b0a848d7f6a1116969b64d035f20050707`

## Targeted local verification

Command:

`python -S -W error::ResourceWarning -m unittest -v test_transactional_store`

Result: **9 tests / PASS / exit 0**

Transcript SHA-256:
`be05030fa2a01983796cf2c9ee82ec32140a25bc847a2fe520147847f064ac9d`

The concurrency test used 24 threads, each opening an independent SQLite connection,
and verified 24 state-version increments with no lost updates.

## What this proves

- atomic state + outbox commit behavior
- rollback when the mutation fails
- rollback when outbox uniqueness fails
- independent-connection write serialization
- persistent state across reopened store instances
- ordered pending outbox records
- idempotent delivery marking
- SQLite integrity check

## What this does NOT prove

- `server.py` integration is not implemented.
- A true separate-OS-process concurrency test has not been run.
- Full Command Center regression has not been run for this branch.
- Migration from `data/state.json` has not been implemented or tested.
- Production use is not authorized.

## Next safe slice

Add an adapter layer behind a feature flag so the existing JSON state path remains the
default. Then run the entire existing Command Center suite against both persistence
backends plus migration/rollback tests. Only after that should ReleaseProof consider
promotion.
