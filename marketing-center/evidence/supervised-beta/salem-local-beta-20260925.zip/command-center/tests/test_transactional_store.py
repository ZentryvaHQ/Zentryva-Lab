import sqlite3
import tempfile
import threading
import unittest
from pathlib import Path

from transactional_store import SQLiteStateOutbox


class SQLiteStateOutboxTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "command-center.db"
        self.store = SQLiteStateOutbox(self.path)
        self.store.initialize({"count": 0})

    def tearDown(self):
        self.tmp.cleanup()

    def increment(self, state):
        state["count"] += 1

    def test_initial_state_is_persistent(self):
        state, version = self.store.read_state()
        self.assertEqual(state, {"count": 0})
        self.assertEqual(version, 0)
        reopened = SQLiteStateOutbox(self.path)
        self.assertEqual(reopened.read_state(), ({"count": 0}, 0))

    def test_state_and_outbox_commit_atomically(self):
        state, version, record = self.store.mutate(
            self.increment,
            event_type="COUNT_INCREMENTED",
            event_payload={"reason": "test"},
            event_id="evt-1",
        )
        self.assertEqual(state["count"], 1)
        self.assertEqual(version, 1)
        self.assertEqual(record.state_version, 1)
        pending = self.store.pending()
        self.assertEqual([row.event_id for row in pending], ["evt-1"])

    def test_mutator_failure_rolls_back_state_and_outbox(self):
        def fail(state):
            state["count"] = 999
            raise RuntimeError("boom")

        with self.assertRaisesRegex(RuntimeError, "boom"):
            self.store.mutate(
                fail,
                event_type="SHOULD_NOT_EXIST",
                event_payload={},
                event_id="evt-fail",
            )
        self.assertEqual(self.store.read_state(), ({"count": 0}, 0))
        self.assertEqual(self.store.pending(), ())

    def test_duplicate_event_id_rolls_back_state(self):
        self.store.mutate(
            self.increment,
            event_type="COUNT_INCREMENTED",
            event_payload={},
            event_id="evt-dup",
        )
        with self.assertRaises(sqlite3.IntegrityError):
            self.store.mutate(
                self.increment,
                event_type="COUNT_INCREMENTED",
                event_payload={},
                event_id="evt-dup",
            )
        self.assertEqual(self.store.read_state(), ({"count": 1}, 1))
        self.assertEqual(len(self.store.pending()), 1)

    def test_concurrent_independent_connections_do_not_lose_updates(self):
        count = 24
        errors = []
        barrier = threading.Barrier(count)

        def work(index):
            try:
                barrier.wait()
                SQLiteStateOutbox(self.path).mutate(
                    self.increment,
                    event_type="COUNT_INCREMENTED",
                    event_payload={"index": index},
                    event_id=f"evt-{index}",
                )
            except Exception as error:
                errors.append(error)

        threads = [threading.Thread(target=work, args=(i,)) for i in range(count)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()

        self.assertEqual(errors, [])
        state, version = self.store.read_state()
        self.assertEqual(state["count"], count)
        self.assertEqual(version, count)
        pending = self.store.pending()
        self.assertEqual(len(pending), count)
        self.assertEqual(
            [record.state_version for record in pending],
            list(range(1, count + 1)),
        )

    def test_pending_is_ordered_and_bounded(self):
        for index in range(3):
            self.store.mutate(
                self.increment,
                event_type="COUNT_INCREMENTED",
                event_payload={"index": index},
                event_id=f"evt-{index}",
            )
        first_two = self.store.pending(limit=2)
        self.assertEqual([row.event_id for row in first_two], ["evt-0", "evt-1"])
        with self.assertRaisesRegex(ValueError, "between 1 and 1000"):
            self.store.pending(limit=0)

    def test_mark_delivered_is_idempotent(self):
        self.store.mutate(
            self.increment,
            event_type="COUNT_INCREMENTED",
            event_payload={},
            event_id="evt-deliver",
        )
        self.assertTrue(self.store.mark_delivered("evt-deliver"))
        self.assertFalse(self.store.mark_delivered("evt-deliver"))
        self.assertEqual(self.store.pending(), ())

    def test_integrity_check_passes(self):
        self.assertTrue(self.store.integrity_check())

    def test_initialize_does_not_overwrite_existing_state(self):
        self.store.mutate(
            self.increment,
            event_type="COUNT_INCREMENTED",
            event_payload={},
            event_id="evt-existing",
        )
        SQLiteStateOutbox(self.path).initialize({"count": 500})
        self.assertEqual(self.store.read_state(), ({"count": 1}, 1))


if __name__ == "__main__":
    unittest.main()
