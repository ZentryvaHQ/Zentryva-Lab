import json
import http.client
import os
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest import mock
import server


class HttpWorkerRoundtripTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        server.DATA=Path(self.tmp.name)
        server.STATE=server.DATA/'state.json'
        server.EVENTS=server.DATA/'events.jsonl'
        server.EVENTS.touch()
        server.STATE.write_text(json.dumps({
            'settings':{'stall_after_seconds':900},
            'projects':[{'id':'p1','status':'RUNNING','desired_state':'RUNNING','assigned_worker_id':'w1'}],
            'workers':[{'id':'w1','state':'IDLE','current_project_id':'p1'}],
            'providers':[{'id':'local','enabled':True}], 'attention':[], 'runs':[]}))
        self.env=mock.patch.dict(os.environ,{
            'ZENTRYVA_CONTROL_TOKEN':'owner-secret',
            'ZENTRYVA_WORKER_TOKENS':'{"w1":"worker-secret"}'},clear=True)
        self.env.start()
        self.http=ThreadingHTTPServer(('127.0.0.1',0),server.Handler)
        self.thread=threading.Thread(target=self.http.serve_forever,daemon=True)
        self.thread.start()
        self.base=f'http://127.0.0.1:{self.http.server_port}'

    def tearDown(self):
        self.http.shutdown()
        self.http.server_close()
        self.thread.join()
        self.env.stop()
        self.tmp.cleanup()

    def request(self,path,token,body=None):
        data=None if body is None else json.dumps(body).encode()
        connection=http.client.HTTPConnection('127.0.0.1',self.http.server_port,timeout=5)
        connection.request('GET' if body is None else 'POST',path,body=data,
            headers={'Authorization':f'Bearer {token}','Content-Type':'application/json'})
        response=connection.getresponse()
        status=response.status
        self.last_headers=dict(response.getheaders())
        payload=json.loads(response.read())
        connection.close()
        return status,payload

    def test_authenticated_receipt_checkpoint_and_result_roundtrip(self):
        status,created=self.request('/api/execution/request','owner-secret',{
            'run_id':'http-r1','project_id':'p1','provider_id':'local',
            'worker_id':'w1','action':'isolated-safe-check'})
        self.assertEqual(status,201)
        self.assertEqual(created['run']['status'],'QUEUED')
        self.assertEqual(self.last_headers['X-Content-Type-Options'],'nosniff')
        self.assertEqual(self.last_headers['Cache-Control'],'no-store')

        status,_=self.request('/api/execution/pending?worker_id=w1','owner-secret')
        self.assertEqual(status,401)
        status,pending=self.request('/api/execution/pending?worker_id=w1','worker-secret')
        self.assertEqual(status,200)
        self.assertEqual([r['id'] for r in pending['runs']],['http-r1'])

        status,_=self.request('/api/evidence','owner-secret',{
            'run_id':'http-r1','worker_id':'w1','kind':'receipt',
            'evidence':{'remote_id':'unauthorized'}})
        self.assertEqual(status,401)
        status,receipt=self.request('/api/evidence','worker-secret',{
            'run_id':'http-r1','worker_id':'w1','kind':'receipt',
            'evidence':{'remote_id':'receipt-http-r1'}})
        self.assertEqual(status,201)
        status,checkpoint=self.request('/api/evidence','worker-secret',{
            'run_id':'http-r1','worker_id':'w1','kind':'checkpoint',
            'evidence':{'checkpoint':'safe-before-action'}})
        self.assertEqual(status,201)
        status,ack=self.request('/api/execution/acknowledge','worker-secret',{
            'run_id':'http-r1','worker_id':'w1','receipt_ref':receipt['evidence_ref'],
            'checkpoint_ref':checkpoint['evidence_ref']})
        self.assertEqual(status,200)
        self.assertEqual(ack['run']['status'],'RUNNING')

        status,_=self.request('/api/execution/complete','worker-secret',{
            'run_id':'http-r1','worker_id':'w1','status':'COMPLETE'})
        self.assertEqual(status,400)
        status,result=self.request('/api/evidence','worker-secret',{
            'run_id':'http-r1','worker_id':'w1','kind':'result',
            'evidence':{'exit_code':0,'output_sha256':'0'*64}})
        self.assertEqual(status,201)
        status,done=self.request('/api/execution/complete','worker-secret',{
            'run_id':'http-r1','worker_id':'w1','status':'COMPLETE',
            'evidence_ref':result['evidence_ref'],'summary':'isolated adapter check'})
        self.assertEqual(status,200)
        self.assertEqual(done['run']['status'],'COMPLETE')
        self.assertEqual(done['run']['checkpoint_ref'],checkpoint['evidence_ref'])
        events=[json.loads(x) for x in server.EVENTS.read_text().splitlines()]
        self.assertEqual([e['type'] for e in events],
            ['EXECUTION_REQUESTED','EXECUTION_ACKNOWLEDGED','EXECUTION_COMPLETED'])

    def test_oversized_json_body_is_rejected(self):
        connection=http.client.HTTPConnection('127.0.0.1',self.http.server_port,timeout=5)
        connection.request('POST','/api/execution/request',body=b'x'*(server.Handler.MAX_JSON_BODY+1),
            headers={'Authorization':'Bearer owner-secret','Content-Type':'application/json'})
        response=connection.getresponse()
        self.assertEqual(response.status,400)
        self.assertIn('exceeds limit',json.loads(response.read())['error'])
        connection.close()

if __name__=='__main__': unittest.main()
