import json
from pathlib import Path
import tempfile
import unittest

from state_backend import (
    JsonFileStateBackend,
    SQLiteStateBackend,
    build_state_backend,
)


class StateBackendTests(unittest.TestCase):
    def seed(self, root: Path):
        state = {
            "projects": [],
            "workers": [],
            "runs": [],
            "providers": [],
            "attention": [],
        }
        (root / "state.json").write_text(
            json.dumps(state),
            encoding="utf-8",
        )
        return state

    def test_json_is_default(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.seed(root)
            backend = build_state_backend(data_dir=root, mode="json")
            self.assertIsInstance(backend, JsonFileStateBackend)

    def test_invalid_mode_fails_closed(self):
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaises(ValueError):
                build_state_backend(data_dir=temporary, mode="redis")

    def test_json_mutation_preserves_compatibility(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.seed(root)
            backend = JsonFileStateBackend(
                root / "state.json",
                root / "events.jsonl",
            )

            def mutate(state):
                state["projects"].append({"id": "p1"})

            state, version, event = backend.mutate(
                mutate,
                event_type="TEST",
                event_payload={"project_id": "p1"},
                event_id="evt-1",
            )

            self.assertEqual(version, 0)
            self.assertEqual(state["projects"][0]["id"], "p1")
            saved = json.loads(
                (root / "state.json").read_text(encoding="utf-8")
            )
            self.assertEqual(saved, state)
            event_line = json.loads(
                (root / "events.jsonl")
                .read_text(encoding="utf-8")
                .strip()
            )
            self.assertEqual(event_line["id"], "evt-1")
            self.assertEqual(event_line["type"], "TEST")
            self.assertEqual(event.event_id, "evt-1")

    def test_sqlite_mutation_creates_durable_outbox(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            initial = self.seed(root)
            backend = SQLiteStateBackend(
                root / "state.sqlite3",
                initial_state=initial,
            )

            def mutate(state):
                state["attention"].append({"id": "a1"})

            state, version, _event = backend.mutate(
                mutate,
                event_type="ATTENTION",
                event_payload={"id": "a1"},
                event_id="evt-2",
            )

            self.assertEqual(version, 1)
            self.assertEqual(state["attention"][0]["id"], "a1")
            pending = backend.store.pending()
            self.assertEqual(len(pending), 1)
            self.assertEqual(pending[0].event_id, "evt-2")

            reopened = SQLiteStateBackend(root / "state.sqlite3")
            self.assertEqual(reopened.load_state(), state)

    def test_sqlite_initialization_does_not_overwrite_existing_state(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            initial = {"projects": [{"id": "first"}]}
            SQLiteStateBackend(
                root / "state.sqlite3",
                initial_state=initial,
            )
            reopened = SQLiteStateBackend(
                root / "state.sqlite3",
                initial_state={"projects": [{"id": "wrong"}]},
            )
            self.assertEqual(
                reopened.load_state()["projects"][0]["id"],
                "first",
            )


if __name__ == "__main__":
    unittest.main()
