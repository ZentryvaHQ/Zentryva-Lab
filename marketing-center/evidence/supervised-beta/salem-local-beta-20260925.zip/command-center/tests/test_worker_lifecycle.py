import json
import tempfile
import threading
import unittest
from pathlib import Path
from unittest import mock
import server


class WorkerLifecycleTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        server.DATA=Path(self.tmp.name)
        server.STATE=server.DATA/'state.json'
        server.EVENTS=server.DATA/'events.jsonl'
        server.EVENTS.touch()
        server.STATE.write_text(json.dumps({
            'settings':{'stall_after_seconds':900},
            'projects':[{'id':'p1','status':'RUNNING','desired_state':'RUNNING','assigned_worker_id':'w1'}],
            'workers':[{'id':'w1','state':'IDLE','current_project_id':'p1'},
                       {'id':'w2','state':'IDLE','current_project_id':None}],
            'providers':[{'id':'local','enabled':True}], 'attention':[], 'runs':[]}))

    def tearDown(self): self.tmp.cleanup()

    def request(self,run_id='r1'):
        return server.request_execution({'run_id':run_id,'project_id':'p1',
            'provider_id':'local','worker_id':'w1','action':'safe-check'})[0]

    def evidence(self,kind,run_id='r1',worker_id='w1'):
        return server.store_evidence({'run_id':run_id,'worker_id':worker_id,
            'kind':kind,'evidence':{'test':kind}})[0]

    def test_worker_must_be_assigned(self):
        with self.assertRaisesRegex(ValueError,'not assigned'):
            server.request_execution({'run_id':'bad','project_id':'p1',
                'provider_id':'local','worker_id':'w2','action':'safe-check'})

    def test_acknowledgement_requires_owner_and_checkpoint_refs(self):
        self.request()
        with self.assertRaisesRegex(ValueError,'worker does not own'):
            server.acknowledge_execution({'run_id':'r1','worker_id':'w2',
                'receipt_ref':'receipt','checkpoint_ref':'checkpoint'})
        with self.assertRaisesRegex(ValueError,'checkpoint_ref'):
            server.acknowledge_execution({'run_id':'r1','worker_id':'w1','receipt_ref':'receipt'})
        with self.assertRaisesRegex(ValueError,'64 lowercase hex'):
            server.acknowledge_execution({'run_id':'r1','worker_id':'w1',
                'receipt_ref':'receipt','checkpoint_ref':'checkpoint'})
        missing='sha256:'+'0'*64
        with self.assertRaisesRegex(ValueError,'was not found'):
            server.acknowledge_execution({'run_id':'r1','worker_id':'w1',
                'receipt_ref':missing,'checkpoint_ref':missing})

    def test_completion_requires_acknowledgement_identity_and_evidence(self):
        self.request()
        with self.assertRaisesRegex(ValueError,'acknowledgement'):
            server.complete_execution({'run_id':'r1','worker_id':'w1',
                'status':'COMPLETE','evidence_ref':'sha256:x'})
        receipt=self.evidence('receipt')
        checkpoint=self.evidence('checkpoint')
        server.acknowledge_execution({'run_id':'r1','worker_id':'w1',
            'receipt_ref':receipt,'checkpoint_ref':checkpoint})
        with self.assertRaisesRegex(ValueError,'does not own'):
            server.complete_execution({'run_id':'r1','worker_id':'w2',
                'status':'COMPLETE','evidence_ref':'sha256:x'})
        with self.assertRaisesRegex(ValueError,'evidence_ref'):
            server.complete_execution({'run_id':'r1','worker_id':'w1','status':'COMPLETE'})
        result=self.evidence('result')
        run,_=server.complete_execution({'run_id':'r1','worker_id':'w1',
            'status':'COMPLETE','evidence_ref':result})
        self.assertEqual(run['status'],'COMPLETE')
        self.assertEqual([json.loads(x)['type'] for x in server.EVENTS.read_text().splitlines()],
            ['EXECUTION_REQUESTED','EXECUTION_ACKNOWLEDGED','EXECUTION_COMPLETED'])

    def test_evidence_is_bound_to_kind_run_and_worker(self):
        self.request('r1')
        self.request('r2')
        receipt=self.evidence('receipt','r1')
        checkpoint=self.evidence('checkpoint','r1')
        with self.assertRaisesRegex(ValueError,'does not match run and worker'):
            server.acknowledge_execution({'run_id':'r2','worker_id':'w1',
                'receipt_ref':receipt,'checkpoint_ref':checkpoint})
        with self.assertRaisesRegex(ValueError,'checkpoint evidence'):
            server.acknowledge_execution({'run_id':'r1','worker_id':'w1',
                'receipt_ref':receipt,'checkpoint_ref':receipt})

    def test_tampered_evidence_is_rejected(self):
        self.request()
        receipt=self.evidence('receipt')
        path=server.evidence_path(receipt)
        path.write_text('{}\n',encoding='utf-8')
        checkpoint=self.evidence('checkpoint')
        with self.assertRaisesRegex(ValueError,'hash does not match'):
            server.acknowledge_execution({'run_id':'r1','worker_id':'w1',
                'receipt_ref':receipt,'checkpoint_ref':checkpoint})

    def test_pending_runs_are_scoped_to_worker(self):
        self.request()
        self.assertEqual([r['id'] for r in server.pending_executions('w1')],['r1'])
        self.assertEqual(server.pending_executions('w2'),[])

    def test_worker_tokens_are_scoped_and_deny_by_default(self):
        with mock.patch.dict('os.environ',{},clear=True):
            self.assertEqual(server.worker_token_status('w1','Bearer x'),'NOT_CONFIGURED')
        with mock.patch.dict('os.environ',{'ZENTRYVA_WORKER_TOKENS':'{"w1":"one","w2":"two"}'},clear=True):
            self.assertEqual(server.worker_token_status('w1','Bearer one'),'AUTHORIZED')
            self.assertEqual(server.worker_token_status('w1','Bearer two'),'UNAUTHORIZED')

    def test_parallel_control_updates_do_not_lose_events(self):
        count=40
        barrier=threading.Barrier(count)
        errors=[]
        def write(index):
            try:
                barrier.wait()
                server.apply_control({'type':'INSTRUCTION','project_id':'p1',
                    'instruction':f'job-{index}','requested_by':'test'})
            except Exception as error:
                errors.append(error)
        threads=[threading.Thread(target=write,args=(i,)) for i in range(count)]
        for thread in threads: thread.start()
        for thread in threads: thread.join()
        self.assertEqual(errors,[])
        events=[json.loads(x) for x in server.EVENTS.read_text().splitlines()]
        self.assertEqual(len(events),count)
        self.assertEqual({e['instruction'] for e in events},{f'job-{i}' for i in range(count)})

if __name__=='__main__': unittest.main()
