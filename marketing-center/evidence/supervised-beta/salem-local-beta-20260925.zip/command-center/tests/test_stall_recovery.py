#!/usr/bin/env python3
import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

import server


class StallRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        server.DATA = root
        server.STATE = root / "state.json"
        server.EVENTS = root / "events.jsonl"
        server.EVENTS.touch()
        stale = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat().replace("+00:00", "Z")
        self.base = {
            "settings": {"stall_after_seconds": 10},
            "projects": [{
                "id": "p1", "name": "P1", "status": "RUNNING",
                "priority": "P1", "desired_state": "RUNNING",
                "assigned_worker_id": "w1", "relationships": []
            }],
            "workers": [{
                "id": "w1", "state": "RUNNING",
                "last_progress_at": stale,
                "last_heartbeat_at": stale,
                "current_project_id": "p1"
            }],
            "attention": []
        }

    def tearDown(self):
        self.tmp.cleanup()

    def write_state(self, state):
        server.STATE.write_text(json.dumps(state), encoding="utf-8")

    def event_types(self):
        return [json.loads(x)["type"] for x in server.EVENTS.read_text().splitlines()]

    def test_configured_healthy_fallback_is_rerouted(self):
        state = json.loads(json.dumps(self.base))
        state["workers"][0]["fallback_worker_id"] = "w2"
        state["workers"].append({
            "id": "w2", "state": "IDLE",
            "last_progress_at": None, "last_heartbeat_at": server.now(),
            "current_project_id": None
        })
        self.write_state(state)
        result = server.supervisor_tick()
        self.assertEqual(result["workers"][0]["state"], "STALLED")
        self.assertEqual(result["projects"][0]["assigned_worker_id"], "w2")
        self.assertEqual(result["projects"][0]["status"], "WAITING")
        self.assertEqual(result["workers"][1]["state"], "RETRYING")
        self.assertEqual(result["workers"][1]["current_project_id"], "p1")
        self.assertIsNone(result["workers"][1]["last_progress_at"])
        self.assertEqual(self.event_types(), ["STALL_DETECTED", "REROUTE_REQUESTED"])

    def test_missing_fallback_escalates_once(self):
        self.write_state(self.base)
        first = server.supervisor_tick()
        self.assertEqual(first["projects"][0]["status"], "SUSPECTED_STALL")
        self.assertEqual(first["attention"][0]["id"], "stall-w1")
        self.assertEqual(first["attention"][0]["status"], "OPEN")
        server.supervisor_tick()
        second = server.load_state()
        self.assertEqual(len([a for a in second["attention"] if a["id"] == "stall-w1"]), 1)
        self.assertEqual(self.event_types(), ["STALL_DETECTED", "STALL_ESCALATED"])


if __name__ == "__main__":
    unittest.main()
