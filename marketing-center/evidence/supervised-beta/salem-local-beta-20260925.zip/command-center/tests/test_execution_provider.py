#!/usr/bin/env python3
import json
import tempfile
import unittest
from pathlib import Path

import server


class ExecutionProviderTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        server.DATA = root
        server.STATE = root / "state.json"
        server.EVENTS = root / "events.jsonl"
        server.EVENTS.touch()
        server.STATE.write_text(json.dumps({
            "settings": {"stall_after_seconds": 900},
            "projects": [{
                "id": "p1", "name": "P1", "status": "RUNNING",
                "priority": "P1", "desired_state": "RUNNING",
                "assigned_worker_id": "w1", "relationships": []
            }],
            "workers": [{"id": "w1", "state": "IDLE", "current_project_id": "p1"}],
            "attention": [],
            "runs": [],
            "providers": [{
                "id": "provider-1", "name": "Test provider",
                "kind": "MOCK", "capabilities": ["test"],
                "enabled": True, "approval_mode": "CONTROLLER"
            }, {
                "id": "provider-disabled", "name": "Disabled provider",
                "kind": "MOCK", "capabilities": [],
                "enabled": False, "approval_mode": "CONTROLLER"
            }]
        }), encoding="utf-8")

    def tearDown(self):
        self.tmp.cleanup()

    def evidence(self, kind, run_id):
        return server.store_evidence({
            "run_id": run_id, "worker_id": "w1", "kind": kind,
            "evidence": {"test": kind}
        })[0]

    def test_non_gated_request_and_completion_are_audited(self):
        run, state = server.request_execution({
            "run_id": "r1", "project_id": "p1",
            "provider_id": "provider-1", "worker_id": "w1", "action": "safe-test"
        })
        self.assertEqual(run["status"], "QUEUED")
        receipt = self.evidence("receipt", "r1")
        checkpoint = self.evidence("checkpoint", "r1")
        server.acknowledge_execution({
            "run_id": "r1", "worker_id": "w1",
            "receipt_ref": receipt, "checkpoint_ref": checkpoint
        })
        result = self.evidence("result", "r1")
        completed, state = server.complete_execution({
            "run_id": "r1", "worker_id": "w1", "status": "COMPLETE",
            "evidence_ref": result, "summary": "verified"
        })
        self.assertEqual(completed["status"], "COMPLETE")
        self.assertEqual(completed["evidence_ref"], result)
        events = [json.loads(line) for line in server.EVENTS.read_text().splitlines()]
        self.assertEqual([e["type"] for e in events],
                         ["EXECUTION_REQUESTED", "EXECUTION_ACKNOWLEDGED", "EXECUTION_COMPLETED"])

    def test_owner_gate_blocks_completion_until_approval(self):
        run, state = server.request_execution({
            "run_id": "r2", "project_id": "p1",
            "provider_id": "provider-1", "worker_id": "w1", "action": "owner-gated",
            "requires_owner_approval": True
        })
        self.assertEqual(run["status"], "WAITING_FOR_OWNER")
        self.assertEqual(state["attention"][-1]["id"], "run-r2")
        with self.assertRaisesRegex(ValueError, "owner approval"):
            server.complete_execution({"run_id": "r2", "worker_id": "w1", "status": "COMPLETE", "evidence_ref": "sha256:blocked"})
        server.apply_control({
            "type": "APPROVAL", "project_id": "p1",
            "blocker_id": "run-r2", "requested_by": "owner"
        })
        receipt = self.evidence("receipt", "r2")
        checkpoint = self.evidence("checkpoint", "r2")
        server.acknowledge_execution({
            "run_id": "r2", "worker_id": "w1",
            "receipt_ref": receipt, "checkpoint_ref": checkpoint
        })
        result = self.evidence("result", "r2")
        completed, _ = server.complete_execution({
            "run_id": "r2", "worker_id": "w1", "status": "COMPLETE",
            "evidence_ref": result
        })
        self.assertEqual(completed["status"], "COMPLETE")

    def test_rejection_is_terminal(self):
        server.request_execution({
            "run_id": "r3", "project_id": "p1",
            "provider_id": "provider-1", "worker_id": "w1", "action": "owner-gated",
            "requires_owner_approval": True
        })
        server.apply_control({
            "type": "REJECTION", "project_id": "p1",
            "blocker_id": "run-r3", "requested_by": "owner"
        })
        with self.assertRaisesRegex(ValueError, "rejected by owner"):
            server.complete_execution({"run_id": "r3", "worker_id": "w1", "status": "COMPLETE", "evidence_ref": "sha256:r3"})

    def test_duplicate_run_and_disabled_provider_are_rejected(self):
        server.request_execution({
            "run_id": "r4", "project_id": "p1",
            "provider_id": "provider-1", "worker_id": "w1", "action": "once"
        })
        with self.assertRaisesRegex(ValueError, "already exists"):
            server.request_execution({
                "run_id": "r4", "project_id": "p1",
                "provider_id": "provider-1", "worker_id": "w1", "action": "twice"
            })
        with self.assertRaisesRegex(ValueError, "missing or disabled"):
            server.request_execution({
                "run_id": "r5", "project_id": "p1",
                "provider_id": "provider-disabled", "worker_id": "w1", "action": "blocked"
            })


if __name__ == "__main__":
    unittest.main()
