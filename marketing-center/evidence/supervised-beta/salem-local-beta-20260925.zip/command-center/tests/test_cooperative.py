"""Shared worker control: real state, ownership and stale-session regressions."""
import json
import unittest
from unittest import mock
import test_execution_provider as fixtures
import server


class CooperativeTests(unittest.TestCase):
    setUp=fixtures.ExecutionProviderTests.setUp
    tearDown=fixtures.ExecutionProviderTests.tearDown
    evidence=fixtures.ExecutionProviderTests.evidence
    def prepare(self):
        server.request_execution(dict(run_id='r1', project_id='p1',
            provider_id='provider-1', worker_id='w1', action='marketing.shadow.verify',
            protocol='cooperative-v1', input={'tenant_id':'salem'}))
        return dict(run_id='r1', worker_id='w1', session_id='a'*32,
                    receipt_ref=self.evidence('receipt','r1'),
                    checkpoint_ref=self.evidence('checkpoint','r1'))

    def test_protocol_available(self):
        self.assertTrue(callable(getattr(server,'worker_run_status',None)), 'scoped status required')

    def test_status_is_scoped_and_never_exposes_session_or_other_projects(self):
        self.prepare()
        state=server.load_state()
        state['projects'].append(dict(id='private',secret='other-tenant'))
        server.save_state(state)
        view=server.worker_run_status('r1','w1')
        self.assertEqual(view['run']['status'],'QUEUED')
        self.assertNotIn('other-tenant',json.dumps(view))
        with self.assertRaises(KeyError): server.worker_run_status('r1','w2')

    def test_pause_resume_and_stale_session_fencing(self):
        payload=self.prepare()
        with mock.patch.object(server,'lease_clock',return_value=100):
            server.acquire_execution(payload)
            with self.assertRaises(ValueError):
                server.acquire_execution({**payload,'session_id':'b'*32})
            server.apply_control(dict(type='PAUSE_REQUESTED',project_id='p1'))
            self.assertFalse(server.pulse_execution(payload)['runnable'])
            with self.assertRaises(ValueError):
                server.store_evidence(dict(run_id='r1',worker_id='w1',kind='result',
                    session_id='a'*32,evidence={'ok':True}))
            server.apply_control(dict(type='RESUME_REQUESTED',project_id='p1'))
        with mock.patch.object(server,'lease_clock',return_value=131):
            server.acquire_execution({**payload,'session_id':'b'*32})
            with self.assertRaises(ValueError): server.pulse_execution(payload)
            with self.assertRaises(ValueError):
                server.store_evidence(dict(run_id='r1',worker_id='w1',kind='result',
                    session_id='a'*32,evidence={'ok':True}))
            ref=server.store_evidence(dict(run_id='r1',worker_id='w1',kind='result',
                    session_id='b'*32,evidence={'ok':True}))[0]
            with self.assertRaises(ValueError):
                server.complete_execution(dict(run_id='r1',worker_id='w1',status='COMPLETE',evidence_ref=ref))
            server.complete_execution(dict(run_id='r1',worker_id='w1',session_id='b'*32,status='COMPLETE',evidence_ref=ref))
            self.assertEqual(server.worker_run_status('r1','w1')['result']['ok'],True)

    def test_legacy_ack_cannot_bypass_protocol_and_release_allows_resume(self):
        payload=self.prepare()
        with self.assertRaises(ValueError): server.acknowledge_execution(payload)
        server.acquire_execution(payload)
        view=server.worker_run_status('r1','w1')
        self.assertNotIn('session_id',view['run'])
        self.assertNotIn('a'*32,server.STATE.read_text())
        server.release_execution(payload)
        server.acquire_execution({**payload,'session_id':'b'*32})

    def test_reassignment_disabled_provider_and_owner_gate_fail_closed(self):
        payload=self.prepare()
        for change in ['pause','assignment','provider','owner']:
            original=server.load_state()
            state=json.loads(json.dumps(original))
            if change=='pause': state['projects'][0]['desired_state']='PAUSED'
            if change=='assignment': state['projects'][0]['assigned_worker_id']='w2'
            if change=='provider': state['providers'][0]['enabled']=False
            if change=='owner': state['runs'][0]['status']='WAITING_FOR_OWNER'
            server.save_state(state)
            with self.subTest(change=change),self.assertRaises(ValueError): server.acquire_execution(payload)
            server.save_state(original)

    def test_previous_generation_evidence_cannot_complete_recovered_run(self):
        payload=self.prepare()
        server.acquire_execution(payload)
        ref=server.store_evidence(dict(run_id='r1',worker_id='w1',kind='result',
            session_id='a'*32,evidence={'ok':True}))[0]
        server.release_execution(payload)
        server.acquire_execution({**payload,'session_id':'b'*32})
        with self.assertRaises(ValueError):
            server.complete_execution(dict(run_id='r1',worker_id='w1',session_id='b'*32,
                                           status='COMPLETE',evidence_ref=ref))

    def test_concurrent_acquisition_has_one_winner(self):
        from concurrent.futures import ThreadPoolExecutor
        payload=self.prepare()
        def acquire(session):
            try:
                server.acquire_execution({**payload,'session_id':session*32})
                return True
            except ValueError: return False
        with ThreadPoolExecutor(max_workers=2) as pool:
            self.assertEqual(sorted(pool.map(acquire,['a','b'])),[False,True])
        self.assertEqual(server.load_state()['runs'][0]['session_generation'],1)

    def test_new_session_does_not_inherit_previous_stall_clock(self):
        payload=self.prepare()
        state=server.load_state()
        state['workers'][0]['last_progress_at']='2020-01-01T00:00:00Z'
        server.save_state(state)
        server.acquire_execution(payload)
        server.pulse_execution(payload)
        state=server.supervisor_tick()
        self.assertEqual(state['workers'][0]['state'],'RUNNING')
        self.assertEqual(state['attention'],[])

    def test_clock_rollback_cannot_revive_expired_session(self):
        payload=self.prepare()
        with mock.patch.object(server,'lease_clock',return_value=100): server.acquire_execution(payload)
        with mock.patch.object(server,'lease_clock',return_value=131):
            with self.assertRaises(ValueError): server.pulse_execution(payload)
        with mock.patch.object(server,'lease_clock',return_value=90):
            with self.assertRaises(ValueError): server.pulse_execution(payload)

    def test_monotonic_expiry_and_server_restart_fence_old_worker(self):
        payload=self.prepare()
        with mock.patch.object(server,'lease_clock',return_value=100),mock.patch.object(server.time,'monotonic',return_value=100):
            server.acquire_execution(payload)
        with mock.patch.object(server,'lease_clock',return_value=90),mock.patch.object(server.time,'monotonic',return_value=131):
            with self.assertRaises(ValueError): server.pulse_execution(payload)
        with mock.patch.object(server,'SESSION_EPOCH','new-server-process'):
            recovered={**payload,'session_id':'b'*32}
            server.acquire_execution(recovered)
            with self.assertRaises(ValueError): server.pulse_execution(payload)
            self.assertTrue(server.pulse_execution(recovered)['runnable'])
