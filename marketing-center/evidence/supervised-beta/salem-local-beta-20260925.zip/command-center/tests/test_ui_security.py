import unittest
from pathlib import Path


class UiSecurityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root=Path(__file__).resolve().parents[1]
        cls.javascript=(cls.root/'app'/'app.js').read_text(encoding='utf-8')
        cls.html=(cls.root/'app'/'index.html').read_text(encoding='utf-8')

    def test_dynamic_controls_do_not_use_inline_handlers(self):
        self.assertNotIn('onclick=',self.javascript)
        self.assertIn('data-project-id=',self.javascript)
        self.assertIn('data-attention-type=',self.javascript)
        self.assertIn('document.addEventListener("click"',self.javascript)

    def test_content_security_policy_disallows_inline_scripts(self):
        self.assertIn('Content-Security-Policy',self.html)
        self.assertIn("script-src 'self'",self.html)
        self.assertNotIn("'unsafe-inline'",self.html)

if __name__=='__main__': unittest.main()
