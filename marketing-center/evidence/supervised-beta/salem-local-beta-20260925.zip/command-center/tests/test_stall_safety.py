import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
import server


class StallSafetyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        server.DATA = Path(self.tmp.name)
        server.STATE = server.DATA / 'state.json'
        server.EVENTS = server.DATA / 'events.jsonl'
        server.EVENTS.touch()
        self.stale = (datetime.now(timezone.utc)-timedelta(hours=1)).isoformat()
        self.state = {
            'settings': {'stall_after_seconds': 900},
            'projects': [{'id': 'p1', 'status': 'RUNNING', 'desired_state': 'RUNNING', 'assigned_worker_id': 'w1'}],
            'workers': [
                {'id': 'w1', 'state': 'RUNNING', 'current_project_id': 'p1', 'last_progress_at': self.stale, 'fallback_worker_id': 'w2'},
                {'id': 'w2', 'state': 'IDLE', 'current_project_id': None, 'last_progress_at': None, 'last_heartbeat_at': server.now()}],
            'attention': []}

    def tearDown(self):
        self.tmp.cleanup()

    def tick(self):
        server.STATE.write_text(json.dumps(self.state), encoding='utf-8')
        return server.supervisor_tick()

    def assert_not_reserved(self, result):
        self.assertEqual(result['projects'][0]['assigned_worker_id'], 'w1')
        self.assertEqual(result['attention'][0]['status'], 'OPEN')

    def test_busy_worker_keeps_its_assignment(self):
        self.state['workers'][1].update(state='RUNNING', current_project_id='p2', last_progress_at=server.now())
        result = self.tick()
        self.assert_not_reserved(result)
        self.assertEqual(result['workers'][1]['current_project_id'], 'p2')

    def test_idle_but_assigned_worker_is_not_available(self):
        self.state['workers'][1]['current_project_id'] = 'p2'
        self.assert_not_reserved(self.tick())

    def test_missing_stale_invalid_and_future_heartbeats_are_rejected(self):
        future = (datetime.now(timezone.utc)+timedelta(hours=1)).isoformat()
        for stamp in [None, self.stale, 'invalid', '2026-09-20T00:00:00', future]:
            with self.subTest(stamp=stamp):
                self.state['workers'][1]['last_heartbeat_at'] = stamp
                self.assert_not_reserved(self.tick())

    def test_owner_pause_is_preserved(self):
        self.state['projects'][0]['desired_state'] = 'PAUSED'
        result = self.tick()
        self.assert_not_reserved(result)
        self.assertEqual(result['projects'][0]['desired_state'], 'PAUSED')

    def test_old_worker_cannot_reassign_current_owner(self):
        self.state['projects'][0]['assigned_worker_id'] = 'w3'
        result = self.tick()
        self.assertEqual(result['projects'][0]['assigned_worker_id'], 'w3')
        self.assertEqual(result['projects'][0]['status'], 'RUNNING')

    def test_reservation_does_not_fabricate_progress_or_repeat(self):
        first = self.tick()
        self.assertEqual(first['projects'][0]['status'], 'WAITING')
        self.assertEqual(first['workers'][1]['state'], 'RETRYING')
        self.assertIsNone(first['workers'][1]['last_progress_at'])
        server.supervisor_tick()
        events = [json.loads(line)['type'] for line in server.EVENTS.read_text().splitlines()]
        self.assertEqual(events, ['STALL_DETECTED', 'REROUTE_REQUESTED'])

if __name__ == '__main__':
    unittest.main()
