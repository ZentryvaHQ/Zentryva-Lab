#!/usr/bin/env python3
import json, tempfile, unittest
from unittest import mock
from pathlib import Path
import server

class CoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        root=Path(self.tmp.name)
        server.DATA=root
        server.STATE=root/"state.json"
        server.EVENTS=root/"events.jsonl"
        server.EVENTS.touch()
        server.STATE.write_text(json.dumps({
            "settings":{"stall_after_seconds":900},
            "projects":[{"id":"p1","name":"P1","status":"RUNNING","priority":"P1","desired_state":"RUNNING","relationships":[]}],
            "workers":[{"id":"w1","state":"RUNNING","last_heartbeat_at":"2026-09-18T14:00:00Z","last_progress_at":"2026-09-18T14:00:00Z","current_project_id":"p1"}],
            "attention":[{"id":"b1","project_id":"p1","status":"OPEN"}]
        }))
    def tearDown(self): self.tmp.cleanup()

    def test_pause_persists(self):
        event,state=server.apply_control({"type":"PAUSE_REQUESTED","project_id":"p1"})
        self.assertEqual(state["projects"][0]["desired_state"],"PAUSED")
        self.assertEqual(event["type"],"PAUSE_REQUESTED")

    def test_instruction_is_audited(self):
        server.apply_control({"type":"INSTRUCTION","project_id":"p1","instruction":"continue safely"})
        rows=server.EVENTS.read_text().splitlines()
        self.assertEqual(len(rows),1)
        self.assertEqual(json.loads(rows[0])["instruction"],"continue safely")

    def test_unknown_project_rejected(self):
        with self.assertRaises(KeyError):
            server.apply_control({"type":"PAUSE_REQUESTED","project_id":"missing"})

    def test_unsupported_control_rejected(self):
        with self.assertRaises(ValueError):
            server.apply_control({"type":"DELETE","project_id":"p1"})

    def test_approval_resolves_attention_persistently(self):
        server.apply_control({"type":"APPROVAL","project_id":"p1","blocker_id":"b1"})
        state=server.load_state()
        self.assertEqual(state["attention"][0]["status"],"RESOLVED")
        self.assertEqual(state["attention"][0]["resolution"],"APPROVAL")

    def test_invalid_worker_state_rejected(self):
        with self.assertRaises(ValueError):
            server.apply_heartbeat({"worker_id":"w1","state":"OWNED"})

    def test_unknown_heartbeat_project_rejected(self):
        with self.assertRaises(ValueError):
            server.apply_heartbeat({"worker_id":"w1","current_project_id":"missing"})

    def test_path_traversal_is_contained(self):
        handler=object.__new__(server.Handler)
        translated=Path(handler.translate_path("/../server.py")).resolve()
        translated.relative_to(server.APP.resolve())

    def test_api_token_is_deny_by_default(self):
        with mock.patch.dict("os.environ",{},clear=True):
            self.assertEqual(server.api_token_status("Bearer anything"),"NOT_CONFIGURED")

    def test_api_token_comparison(self):
        with mock.patch.dict("os.environ",{"ZENTRYVA_CONTROL_TOKEN":"secret"},clear=True):
            self.assertEqual(server.api_token_status("Bearer secret"),"AUTHORIZED")
            self.assertEqual(server.api_token_status("Bearer wrong"),"UNAUTHORIZED")

if __name__=="__main__":
    unittest.main()
