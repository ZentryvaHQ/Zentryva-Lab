# Zentryva Command Center Core

Portable core for the Zentryva graphical operations console and data/control layer.

## Run locally

Requires Python 3.10+ and no third-party packages.

Set a private control token for the local session, then start the server. Do not commit or paste the token into logs or handoffs.

```bash
export ZENTRYVA_CONTROL_TOKEN='replace-with-a-private-random-value'
python server.py
```

PowerShell:

```powershell
$env:ZENTRYVA_CONTROL_TOKEN = 'replace-with-a-private-random-value'
python server.py
```

Open `http://127.0.0.1:8080`.

## Current MVP capabilities
- project and worker dashboard
- dependency/relationship view
- owner attention queue
- persistent pause/resume/retry/instruction events
- worker heartbeat endpoint
- progress-based stall detection
- worker-scoped receipt, checkpoint, acknowledgement and evidence lifecycle
- immutable SHA-256 evidence records bound to the run, worker and lifecycle kind
- serialized in-process state mutations for concurrent HTTP handlers
- provider-neutral module, worker and handoff contracts
- append-only JSONL event audit trail

## Important boundary
A control event is a request until a real worker adapter acknowledges and executes it. The UI must not present a remote ChatGPT account as controlled unless an adapter for that environment is actually connected.

See `docs/ARCHITECTURE.md` and `docs/24H_MVP.md`.
